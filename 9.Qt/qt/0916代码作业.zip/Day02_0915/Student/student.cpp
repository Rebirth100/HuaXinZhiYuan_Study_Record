#include "student.h"
#include "ui_student.h"
#include <QHBoxLayout>//水平布局：单行
#include <QVBoxLayout>//垂直布局：单列
#include <QGridLayout>//网格布局：多行多列
#include <QFormLayout>//单表布局：永远两列，左边文字，右边输入框
Student::Student(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Student)
{
    ui->setupUi(this);
    //通过水平和垂直的方法
    /*
    QHBoxLayout* hLayout_1 = new QHBoxLayout;
    hLayout_1->addStretch();
    hLayout_1->addWidget(ui->label_Title);
    hLayout_1->addStretch();
    QHBoxLayout* hLayout_2 = new QHBoxLayout;
    hLayout_2->addWidget(ui->label_Info);
    QHBoxLayout* hLayout_3 = new QHBoxLayout;
    hLayout_3->addWidget(ui->label_Name);
    hLayout_3->addWidget(ui->lineEdit_Name);
    hLayout_3->addStretch();
    hLayout_3->addWidget(ui->label_Age);
    hLayout_3->addWidget(ui->spinBox_Age);
    hLayout_3->addStretch();
    hLayout_3->addWidget(ui->label_Gen);
    hLayout_3->addWidget(ui->radioButton_Boy);
    hLayout_3->addWidget(ui->radioButton_Girl);
    hLayout_3->addStretch();
    hLayout_3->addWidget(ui->label_National);
    hLayout_3->addWidget(ui->comboBox_National);
    hLayout_3->addStretch();
    QHBoxLayout* hLayout_4 = new QHBoxLayout;
    hLayout_4->addWidget(ui->label_Address);
    hLayout_4->addWidget(ui->comboBox_Province);
    hLayout_4->addWidget(ui->comboBox_City);
    hLayout_4->addStretch();
    hLayout_4->addWidget(ui->label_Date);
    hLayout_4->addWidget(ui->dateEdit_Date);
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    QHBoxLayout* hLayout_5 = new QHBoxLayout;
    hLayout_5->addWidget(ui->label_Course);
    QHBoxLayout* hLayout_6 = new QHBoxLayout;
    hLayout_6->addWidget(ui->checkBox_C);
    hLayout_6->addStretch();
    hLayout_6->addWidget(ui->checkBox_Python);
    hLayout_6->addStretch();
    hLayout_6->addWidget(ui->checkBox_Cpp);
    hLayout_6->addStretch();
    hLayout_6->addWidget(ui->checkBox_Math);
    hLayout_6->addStretch();
    hLayout_6->addWidget(ui->checkBox_Computer_English);
    hLayout_6->addStretch();
    hLayout_6->addWidget(ui->checkBox_Computer_Organization);

    QHBoxLayout* hLayout_7 = new QHBoxLayout;
    hLayout_7->addWidget(ui->checkBox_Computer_Internet);
    hLayout_7->addStretch();
    hLayout_7->addWidget(ui->checkBox_Struct);
    hLayout_7->addStretch();
    hLayout_7->addWidget(ui->checkBox_Databases);
    hLayout_7->addStretch();
    hLayout_7->addWidget(ui->checkBox_OS);
    hLayout_7->addStretch();
    hLayout_7->addWidget(ui->checkBox_Line_Math);
    hLayout_7->addStretch();
    QHBoxLayout* hLayout_8 = new QHBoxLayout;
    hLayout_8->addWidget(ui->checkBox_All_Choice);
    QHBoxLayout* hLayout_9 = new QHBoxLayout;
    hLayout_9->addWidget(ui->label_Comment);
    QHBoxLayout* hLayout_10 = new QHBoxLayout;
    hLayout_10->addStretch();
    hLayout_10->addWidget(ui->textEdit_Comment,1);//拉伸权重1
    hLayout_10->addStretch();
    QHBoxLayout* hLayout_11 = new QHBoxLayout;
    hLayout_11->addStretch();
    hLayout_11->addWidget(ui->pushButton_OK);
    hLayout_11->addStretch();
    QHBoxLayout* hLayout_12 = new QHBoxLayout;
    hLayout_12->addWidget(ui->label_Total_Info);
    QHBoxLayout* hLayout_13 = new QHBoxLayout;
    hLayout_13->addStretch();
    hLayout_13->addWidget(ui->textBrowser_Display,1);//拉伸权重1
    hLayout_13->addStretch();
    QVBoxLayout* vLayout = new QVBoxLayout;
    vLayout->addStretch();
    vLayout->addLayout(hLayout_1);
    vLayout->addStretch();
    vLayout->addWidget(ui->line_2);  // 加入分割线
    vLayout->addLayout(hLayout_2);
    vLayout->addLayout(hLayout_3);
    vLayout->addLayout(hLayout_4);
    vLayout->addLayout(hLayout_5);
    vLayout->addLayout(hLayout_6);
    vLayout->addLayout(hLayout_7);
    vLayout->addLayout(hLayout_8);
    vLayout->addLayout(hLayout_9);
    vLayout->addStretch();
    vLayout->addLayout(hLayout_10);
    vLayout->addStretch();
    vLayout->addLayout(hLayout_11);
    vLayout->addStretch();
    vLayout->addWidget(ui->line_3);  // 加入分割线
    vLayout->addLayout(hLayout_12);
    vLayout->addStretch();
    vLayout->addLayout(hLayout_13);
    vLayout->addStretch();
    setLayout(vLayout);
*/
    //通过网格和单表布局
    QHBoxLayout* hLayout_1 = new QHBoxLayout;
    hLayout_1->addStretch();
    hLayout_1->addWidget(ui->label_Title);
    hLayout_1->addStretch();
    QHBoxLayout* hLayout_2 = new QHBoxLayout;
    hLayout_2->addWidget(ui->label_Info);

    QHBoxLayout* hLayout_3 = new QHBoxLayout;
    hLayout_3->addWidget(ui->label_Name);
    hLayout_3->addWidget(ui->lineEdit_Name);
    hLayout_3->addStretch();
    hLayout_3->addWidget(ui->label_Age);
    hLayout_3->addWidget(ui->spinBox_Age);
    hLayout_3->addStretch();
    hLayout_3->addWidget(ui->label_Gen);
    hLayout_3->addWidget(ui->radioButton_Boy);
    hLayout_3->addWidget(ui->radioButton_Girl);
    hLayout_3->addStretch();
    hLayout_3->addWidget(ui->label_National);
    hLayout_3->addWidget(ui->comboBox_National);
    hLayout_3->addStretch();
    QHBoxLayout* hLayout_4 = new QHBoxLayout;
    hLayout_4->addWidget(ui->label_Address);
    hLayout_4->addWidget(ui->comboBox_Province);
    hLayout_4->addWidget(ui->comboBox_City);
    hLayout_4->addStretch();
    hLayout_4->addWidget(ui->label_Date);
    hLayout_4->addWidget(ui->dateEdit_Date);
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    QHBoxLayout* hLayout_5 = new QHBoxLayout;
    hLayout_5->addWidget(ui->label_Course);

    QGridLayout* gLayout_1 =new QGridLayout;
    gLayout_1->addWidget(ui->checkBox_C,0,0);
    gLayout_1->addWidget(ui->checkBox_Python,0,1);
    gLayout_1->addWidget(ui->checkBox_Cpp,0,2);
    gLayout_1->addWidget(ui->checkBox_Math,0,3);
    gLayout_1->addWidget(ui->checkBox_Computer_English,0,4);
    gLayout_1->addWidget(ui->checkBox_Computer_Organization,0,5);
    gLayout_1->addWidget(ui->checkBox_Computer_Internet,1,0);
    gLayout_1->addWidget(ui->checkBox_Struct,1,1);
    gLayout_1->addWidget(ui->checkBox_Databases,1,2);
    gLayout_1->addWidget(ui->checkBox_OS,1,3);
    gLayout_1->addWidget(ui->checkBox_Line_Math,1,4);
    gLayout_1->addWidget(ui->checkBox_All_Choice,2,0);

    QHBoxLayout* hLayout_6 = new QHBoxLayout;
    hLayout_6->addWidget(ui->label_Comment);
    QHBoxLayout* hLayout_7 = new QHBoxLayout;
    hLayout_7->addStretch();
    hLayout_7->addWidget(ui->textEdit_Comment,1);//拉伸权重1
    hLayout_7->addStretch();
    QHBoxLayout* hLayout_8 = new QHBoxLayout;
    hLayout_8->addStretch();
    hLayout_8->addWidget(ui->pushButton_OK);
    hLayout_8->addStretch();
    QHBoxLayout* hLayout_9 = new QHBoxLayout;
    hLayout_9->addWidget(ui->label_Total_Info);
    QHBoxLayout* hLayout_10 = new QHBoxLayout;
    hLayout_10->addStretch();
    hLayout_10->addWidget(ui->textBrowser_Display,1);//拉伸权重1
    hLayout_10->addStretch();
    QVBoxLayout* vLayout = new QVBoxLayout;
    vLayout->addStretch();
    vLayout->addLayout(hLayout_1);
    vLayout->addStretch();
    vLayout->addWidget(ui->line_2);  // 加入分割线
    vLayout->addLayout(hLayout_2);
    vLayout->addLayout(hLayout_3);
    vLayout->addLayout(hLayout_4);
    vLayout->addLayout(hLayout_5);
    vLayout->addLayout(gLayout_1);//课程网格紧跟课程标题
    vLayout->addLayout(hLayout_6);
    vLayout->addLayout(hLayout_7);
    vLayout->addLayout(hLayout_8);
    vLayout->addWidget(ui->line_3); // 加入分割线
    vLayout->addLayout(hLayout_9);
    vLayout->addLayout(hLayout_10);
    setLayout(vLayout);
}

Student::~Student()
{
    delete ui;
}

void Student::on_pushButton_OK_clicked()
{
    //输出姓名
    QString info = ui->label_Info->text();
    ui->textBrowser_Display->append(info);

    QString name = ui->lineEdit_Name->text();
    QString label_name = ui->label_Name->text();
    QString name_total = label_name + ": " + name;
    ui->textBrowser_Display->append(name_total);//追加，不会被覆盖
    //ui->textBrowser_Display->append(name);

    //输出年龄
    QString age = ui->spinBox_Age->text();
    QString label_age = ui->label_Age->text();
    QString age_total = label_age + ": " + age;
    ui->textBrowser_Display->append(age_total);


    //输出性别
    QString gen ;
    if(ui->radioButton_Boy->isChecked())
    {
        gen = "男";
    }
    else
    {
        gen ="女";
    }
    QString label_gen = ui->label_Gen->text();
    QString gen_total = label_gen + ": " + gen;
    ui->textBrowser_Display->append(gen_total);

    //民族
    QString national = ui->comboBox_National->currentText();
    QString label_national = ui->label_National->text();
    QString national_total = label_national + ": " + national;
    ui->textBrowser_Display->append(national_total);

    //籍贯
    QString province = ui->comboBox_Province->currentText();
    QString city = ui->comboBox_City->currentText();
    QString label_address = ui->label_Address->text();
    QString address_total = label_address + ": " + province + city;
    ui->textBrowser_Display->append(address_total);

    //出生日期
    QString date = ui->dateEdit_Date->date().toString("yyyy-MM-dd");
    QString label_date = ui->label_Date->text();
    QString date_total = label_date + ": " + date;
    ui->textBrowser_Display->append(date_total);

    //课程
    QString course;
    if(ui->checkBox_C->isChecked())
    {
        course +="C语言程序设计，";
    }
    if(ui->checkBox_Python->isChecked())
    {
        course +="Python程序设计，";
    }
    if(ui->checkBox_Cpp->isChecked())
    {
        course +="C++面向对象程序设计，";
    }
    if(ui->checkBox_Math->isChecked())
    {
        course +="高等数学，";
    }
    if(ui->checkBox_Computer_English->isChecked())
    {
        course +="计算机英语，";
    }
    if(ui->checkBox_Computer_Organization->isChecked())
    {
        course +="计算机组成原理，";
    }
    if(ui->checkBox_Computer_Internet->isChecked())
    {
        course +="计算机网络，";
    }
    if(ui->checkBox_Struct->isChecked())
    {
        course +="数据结构，";
    }
    if(ui->checkBox_Databases->isChecked())
    {
        course +="数据库，";
    }
    if(ui->checkBox_OS->isChecked())
    {
        course +="操作系统，";
    }
    if(ui->checkBox_Line_Math->isChecked())
    {
        course +="线性代数，";
    }
    QString label_course = ui->label_Course->text();
    QString course_total = label_course + ": " + course;
    ui->textBrowser_Display->append(course_total);


    //个人评价
    QString comment = ui->textEdit_Comment->toPlainText();
    QString label_comment = ui->label_Comment->text();
    QString comment_total = label_comment + ": " + comment;
    ui->textBrowser_Display->append(comment_total);

}


void Student::on_checkBox_All_Choice_clicked(bool checked)
{
    qDebug()<< "全选框状态：" << checked;
    ui->checkBox_C->setChecked(checked);
    ui->checkBox_Python->setChecked(checked);
    ui->checkBox_Cpp->setChecked(checked);
    ui->checkBox_Math->setChecked(checked);
    ui->checkBox_Computer_English->setChecked(checked);
    ui->checkBox_Computer_Organization->setChecked(checked);
    ui->checkBox_Computer_Internet->setChecked(checked);
    ui->checkBox_Struct->setChecked(checked);
    ui->checkBox_Databases->setChecked(checked);
    ui->checkBox_OS->setChecked(checked);
    ui->checkBox_Line_Math->setChecked(checked);
}

void Student::updateAllCheckState()
{
    bool allChecked = ui->checkBox_C->isChecked()
    && ui->checkBox_Python->isChecked()
    && ui->checkBox_Cpp->isChecked()
    && ui->checkBox_Math->isChecked()
    && ui->checkBox_Computer_English->isChecked()
    && ui->checkBox_Computer_Organization->isChecked()
    && ui->checkBox_Computer_Internet->isChecked()
    && ui->checkBox_Struct->isChecked()
    && ui->checkBox_Databases->isChecked()
    && ui->checkBox_OS->isChecked()
    && ui->checkBox_Line_Math->isChecked();
    ui->checkBox_All_Choice->setChecked(allChecked);
}

void Student::on_checkBox_C_clicked(bool )
{
    updateAllCheckState();
}


void Student::on_checkBox_Python_clicked(bool )
{
    updateAllCheckState();
}


void Student::on_checkBox_Cpp_clicked(bool )
{
    updateAllCheckState();
}


void Student::on_checkBox_Math_clicked(bool )
{
    updateAllCheckState();
}


void Student::on_checkBox_Computer_English_clicked(bool )
{
    updateAllCheckState();
}


void Student::on_checkBox_Computer_Organization_clicked(bool )
{
    updateAllCheckState();
}


void Student::on_checkBox_Computer_Internet_clicked(bool )
{
    updateAllCheckState();
}


void Student::on_checkBox_Struct_clicked(bool )
{
    updateAllCheckState();
}


void Student::on_checkBox_Databases_clicked(bool )
{
    updateAllCheckState();
}


void Student::on_checkBox_OS_clicked(bool )
{
    updateAllCheckState();
}


void Student::on_checkBox_Line_Math_clicked(bool )
{
    updateAllCheckState();
}

