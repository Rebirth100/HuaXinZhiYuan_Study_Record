#ifndef STUDENT_H
#define STUDENT_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui {
class Student;
}
QT_END_NAMESPACE

class Student : public QWidget
{
    Q_OBJECT

public:
    explicit Student(QWidget *parent = nullptr);
    ~Student() override;

private slots:
    void on_pushButton_OK_clicked();
    void on_checkBox_All_Choice_clicked(bool checked);
    void updateAllCheckState();
    void on_checkBox_C_clicked(bool checked);

    void on_checkBox_Python_clicked(bool checked);

    void on_checkBox_Cpp_clicked(bool checked);

    void on_checkBox_Math_clicked(bool checked);

    void on_checkBox_Computer_English_clicked(bool checked);

    void on_checkBox_Computer_Organization_clicked(bool checked);

    void on_checkBox_Computer_Internet_clicked(bool checked);

    void on_checkBox_Struct_clicked(bool checked);

    void on_checkBox_Databases_clicked(bool checked);

    void on_checkBox_OS_clicked(bool checked);

    void on_checkBox_Line_Math_clicked(bool checked);

private:
    Ui::Student *ui;
};
#endif // STUDENT_H
