#include "widget.h"
#include "ui_widget.h"
#include <QHBoxLayout>//水平布局：单行
#include <QVBoxLayout>//垂直布局：单列
#include <QGridLayout>//网格布局：多行多列
#include <QFormLayout>//单表布局：永远两列，左边文字，右边输入框

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    /*方法一
    QHBoxLayout* hLayout_1 = new QHBoxLayout;
    hLayout_1->addStretch();
    hLayout_1->addWidget(ui->lineEdit_display);
    hLayout_1->addStretch();
    QHBoxLayout* hLayout_2 = new QHBoxLayout;
    hLayout_2->addStretch();
    hLayout_2->addWidget(ui->pushButton_number_1);
    hLayout_2->addStretch();
    hLayout_2->addWidget(ui->pushButton_number_2);
    hLayout_2->addStretch();
    hLayout_2->addWidget(ui->pushButton_number_3);
    hLayout_2->addStretch();
    hLayout_2->addWidget(ui->pushButton_number_add);
    hLayout_2->addStretch();
    QHBoxLayout* hLayout_3 = new QHBoxLayout;
    hLayout_3->addStretch();
    hLayout_3->addWidget(ui->pushButton_number_4);
    hLayout_3->addStretch();
    hLayout_3->addWidget(ui->pushButton_number_5);
    hLayout_3->addStretch();
    hLayout_3->addWidget(ui->pushButton_number_6);
    hLayout_3->addStretch();
    hLayout_3->addWidget(ui->pushButton_number_sub);
    hLayout_3->addStretch();
    QHBoxLayout* hLayout_4 = new QHBoxLayout;
    hLayout_4->addStretch();
    hLayout_4->addWidget(ui->pushButton_number_7);
    hLayout_4->addStretch();
    hLayout_4->addWidget(ui->pushButton_number_8);
    hLayout_4->addStretch();
    hLayout_4->addWidget(ui->pushButton_number_9);
    hLayout_4->addStretch();
    hLayout_4->addWidget(ui->pushButton_number_mul);
    hLayout_4->addStretch();
    QHBoxLayout* hLayout_5 = new QHBoxLayout;
    hLayout_5->addStretch();
    hLayout_5->addWidget(ui->pushButton_number_clear);
    hLayout_5->addStretch();
    hLayout_5->addWidget(ui->pushButton_number_0);
    hLayout_5->addStretch();
    hLayout_5->addWidget(ui->pushButton_number_equal);
    hLayout_5->addStretch();
    hLayout_5->addWidget(ui->pushButton_number_div);
    hLayout_5->addStretch();
    QVBoxLayout* vLayout = new QVBoxLayout;
    vLayout->addStretch();
    vLayout->addLayout(hLayout_1);
    vLayout->addStretch();
    vLayout->addLayout(hLayout_2);
    vLayout->addLayout(hLayout_3);
    vLayout->addLayout(hLayout_4);
    vLayout->addLayout(hLayout_5);
    vLayout->addStretch();
    setLayout(vLayout);
    */

    /*方法二*/
    QHBoxLayout* hLayout_1 = new QHBoxLayout;
    hLayout_1->addStretch();
    hLayout_1->addWidget(ui->lineEdit_display);
    hLayout_1->addStretch();
    QGridLayout* gLayout = new QGridLayout;
    gLayout->addWidget(ui->pushButton_number_1,0,0);
    gLayout->addWidget(ui->pushButton_number_2,0,1);
    gLayout->addWidget(ui->pushButton_number_3,0,2);
    gLayout->addWidget(ui->pushButton_number_add,0,3);
    gLayout->addWidget(ui->pushButton_number_4,1,0);
    gLayout->addWidget(ui->pushButton_number_5,1,1);
    gLayout->addWidget(ui->pushButton_number_6,1,2);
    gLayout->addWidget(ui->pushButton_number_sub,1,3);
    gLayout->addWidget(ui->pushButton_number_7,2,0);
    gLayout->addWidget(ui->pushButton_number_8,2,1);
    gLayout->addWidget(ui->pushButton_number_9,2,2);
    gLayout->addWidget(ui->pushButton_number_mul,2,3);
    gLayout->addWidget(ui->pushButton_number_clear,3,0);
    gLayout->addWidget(ui->pushButton_number_0,3,1);
    gLayout->addWidget(ui->pushButton_number_equal,3,2);
    gLayout->addWidget(ui->pushButton_number_div,3,3);
    QVBoxLayout* vLayout = new QVBoxLayout;
    vLayout->addLayout(hLayout_1);
    vLayout->addLayout(gLayout);
    setLayout(vLayout);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButton_number_1_clicked()
{
    int num = 1;
    //判断当前状态
    if(state_ == Begin)
    {
        //根据当前状态做处理，可能什么也不做
        first_number_ = 1;
        num = first_number_;
        //是否改变当前状态
        state_ = First_number;
    }
    else if(state_ == First_number)
    {
        first_number_ *= 10;
        first_number_ += 1;
        num = first_number_;
    }
    else if(state_ == Operation)
    {
        second_number_ = 1;
        num = second_number_;

        state_ = Second_number;
    }
    else if(state_ ==Second_number)
    {
        second_number_ *= 10;
        second_number_ += 1;
        num = second_number_;
    }
    else if(state_ == Equal)
    {
        return;
    }
    else if(state_ ==Result)
    {
        return;
    }

    ui->lineEdit_display->setText(QString::number(num));
}


void Widget::on_pushButton_number_2_clicked()
{

    int num = 2;
    //判断当前状态
    if(state_ == Begin)
    {
        //根据当前状态做处理，可能什么也不做
        first_number_ = 2;
        num = first_number_;
        //是否改变当前状态
        state_ = First_number;
    }
    else if(state_ == First_number)
    {
        first_number_ *= 10;
        first_number_ += 2;
        num = first_number_;
    }
    else if(state_ == Operation)
    {
        second_number_ = 2;
        num = second_number_;

        state_ = Second_number;
    }
    else if(state_ ==Second_number)
    {
        second_number_ *= 10;
        second_number_ += 2;
        num = second_number_;
    }
    else if(state_ == Equal)
    {
        return;
    }
    else if(state_ ==Result)
    {
        return;
    }

    ui->lineEdit_display->setText(QString::number(num));
}

//等号
void Widget::on_pushButton_number_equal_clicked()
{
    int result = 0;
    //判断当前状态
    if(state_ == Begin)
    {
        return;
    }
    else if(state_ == First_number)
    {
        return;
    }
    else if(state_ == Operation)
    {
        return;
    }
    else if(state_ == Second_number)
    {
        if(op_ == '+')
        {
            result = first_number_ + second_number_;
        }
        else if(op_ == '-')
        {
            result = first_number_ - second_number_;
        }
        else if(op_ == '*')
        {
            result = first_number_ * second_number_;
        }
        else if(op_ == '/')
        {
            if(second_number_ == 0)
            {
                ui->lineEdit_display->setText("error");
                state_ = Equal;
                return;
            }
            result = first_number_ / second_number_;
        }
        state_ = Equal;
    }
    else if(state_ == Equal)
    {
        return;
    }
    else if(state_ ==Result)
    {
        return;
    }
    ui->lineEdit_display->setText(QString::number(result));
}

//加法
void Widget::on_pushButton_number_add_clicked()
{
    if(state_ == Begin)
    {
        return;
    }
    else if(state_ == First_number)
    {
        op_ = '+';
        state_ = Operation;
    }
    else if(state_ == Operation)
    {
        return;
    }
    else if(state_ ==Second_number)
    {
        return;
    }
    else if(state_ == Equal)
    {
        return;
    }
    else if(state_ ==Result)
    {
        return;
    }
}

//减法
void Widget::on_pushButton_number_sub_clicked()
{
    if(state_ == Begin)
    {
        return;
    }
    else if(state_ == First_number)
    {
        op_ = '-';
        state_ = Operation;
    }
    else if(state_ == Operation)
    {
        return;
    }
    else if(state_ ==Second_number)
    {
        return;
    }
    else if(state_ == Equal)
    {
        return;
    }
    else if(state_ ==Result)
    {
        return;
    }
}

//乘法
void Widget::on_pushButton_number_mul_clicked()
{
    if(state_ == Begin)
    {
        return;
    }
    else if(state_ == First_number)
    {
        op_ = '*';
        state_ = Operation;
    }
    else if(state_ == Operation)
    {
        return;
    }
    else if(state_ ==Second_number)
    {
        return;
    }
    else if(state_ == Equal)
    {
        return;
    }
    else if(state_ ==Result)
    {
        return;
    }
}

//除法
void Widget::on_pushButton_number_div_clicked()
{
    if(state_ == Begin)
    {
        return;
    }
    else if(state_ == First_number)
    {
        op_ = '/';
        state_ = Operation;
    }
    else if(state_ == Operation)
    {
        return;
    }
    else if(state_ ==Second_number)
    {
        return;
    }
    else if(state_ == Equal)
    {
        return;
    }
    else if(state_ ==Result)
    {
        return;
    }
}


void Widget::on_pushButton_number_clear_clicked()
{
    //重置所有变量
    state_=Begin;
    first_number_ = 0;
    second_number_ = 0;
    op_ = 0;
    //清空输入框
    ui->lineEdit_display->clear();
}


