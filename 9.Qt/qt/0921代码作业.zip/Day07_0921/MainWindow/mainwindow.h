#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QAction>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QComboBox>
#include <QSpinBox>
#include <QCheckBox>
#include <QRadioButton>
#include <QDateEdit>
#include <QTextEdit>
#include <QTextBrowser>
#include <QFrame>


QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;
private slots:
    //自定义槽（不再以on_开头）
    void pushButton_OK_clicked();
    void checkBox_All_Choice_clicked(bool checked);
    void updateAllCheckState();
    void checkBox_C_clicked(bool checked);

    void checkBox_Python_clicked(bool checked);

    void checkBox_Cpp_clicked(bool checked);

    void checkBox_Math_clicked(bool checked);

    void checkBox_Computer_English_clicked(bool checked);

    void checkBox_Computer_Organization_clicked(bool checked);

    void checkBox_Computer_Internet_clicked(bool checked);

    void checkBox_Struct_clicked(bool checked);

    void checkBox_Databases_clicked(bool checked);

    void checkBox_OS_clicked(bool checked);

    void checkBox_Line_Math_clicked(bool checked);

private:

    //动态创建控件，全部声明在这里
    QLabel* label_Title;
    QLabel* label_Info;
    QLabel* label_Name;
    QLabel* label_Age;
    QLabel* label_Gen;
    QLabel* label_National;
    QLabel* label_Address;
    QLabel* label_Date;
    QLabel* label_Course;
    QLabel* label_Comment;
    QLabel* label_Total_Info;

    QLineEdit* lineEdit_Name;
    QSpinBox* spinBox_Age;

    QRadioButton* radioButton_Boy;
    QRadioButton* radioButton_Girl;

    QComboBox* comboBox_National;
    QComboBox* comboBox_Province;
    QComboBox* comboBox_City;

    QDateEdit* dateEdit_Date;

    QCheckBox* checkBox_All_Choice;
    QCheckBox* checkBox_C;
    QCheckBox* checkBox_Python;
    QCheckBox* checkBox_Cpp;
    QCheckBox* checkBox_Math;
    QCheckBox* checkBox_Computer_English;
    QCheckBox* checkBox_Computer_Organization;
    QCheckBox* checkBox_Computer_Internet;
    QCheckBox* checkBox_Struct;
    QCheckBox* checkBox_Databases;
    QCheckBox* checkBox_OS;
    QCheckBox* checkBox_Line_Math;

    QTextEdit* textEdit_Comment;
    QTextBrowser* textBrowser_Display;

    QPushButton* pushButton_OK;

    QFrame* line_2;
    QFrame* line_3;

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
