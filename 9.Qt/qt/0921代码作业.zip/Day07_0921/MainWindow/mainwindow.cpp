#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QToolBar>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QHBoxLayout>
#include <QVBoxLayout>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //1. 菜单栏：QAction、QMenu
    //菜单项action_open被点击（triggered触发）
    connect(ui->action_open,&QAction::triggered,
        [this]
        {
            //QMessageBox::information(this,"title","open");
            ui->statusbar->showMessage("这是一条消息~",3*1000);// 状态栏显示消息，第二个参数是毫秒，3*1000=3秒自动消失
        });
    //QMenu::triggered：菜单里面任意一个action被点击，就会触发，带回被点击的QAction*
    connect(ui->menu_file,&QMenu::triggered,
        [](QAction* action)
        {
            qDebug() << "action=" << action;
    });

    //2. 工具栏 QToolBar 动态创建
    QToolBar* tool_bar =new QToolBar;
    QPushButton* button_open = new QPushButton("打开");
    connect(button_open,&QPushButton::clicked,
        [this]
    {
        QMessageBox::information(this,"title","open");
    });
    tool_bar->addWidget(button_open);// addWidget：往工具栏添加普通控件（按钮、输入框）
    QLineEdit* line_edit = new QLineEdit;
    tool_bar->addWidget(line_edit);
    addToolBar(tool_bar);// QMainWindow成员函数：把工具栏添加到主窗口

    //3. 中心部件 + 布局（计算器简易界面）
    QWidget* widget =new QWidget;// 中心部件载体

    /*------------计算器------------------
    // 创建一堆控件，父对象给widget
    QLineEdit* lineEdit_number_1 = new QLineEdit(widget);
    lineEdit_number_1->setGeometry(100,100,300,20);// 绝对坐标，后面会被布局覆盖掉，这行实际无效
    QLineEdit* lineEdit_number_2 = new QLineEdit(widget);
    QLineEdit* lineEdit_result = new QLineEdit(widget);
    QLabel* label_add = new QLabel("+",widget);
    QLabel* label_equal = new QLabel("=",widget);
    QPushButton* button_calc = new QPushButton("计算",widget);

    QHBoxLayout* hLayout_1 = new QHBoxLayout; //第一行水平布局
    hLayout_1->addWidget(lineEdit_number_1);
    hLayout_1->addWidget(label_add);
    hLayout_1->addWidget(lineEdit_number_2);
    hLayout_1->addWidget(label_equal);
    hLayout_1->addWidget(lineEdit_result);
    QHBoxLayout* hLayout_2 = new QHBoxLayout;// 第二行水平布局：addStretch 弹簧，左右弹簧把按钮挤到中间
    hLayout_2->addStretch();
    hLayout_2->addWidget(button_calc);
    hLayout_2->addStretch();
    QVBoxLayout* vLayout = new QVBoxLayout;// 垂直布局，把上面两行布局摞起来
    vLayout->addLayout(hLayout_1);// addLayout：往布局里面嵌套子布局
    vLayout->addLayout(hLayout_2);
    widget->setLayout(vLayout);// 给widget设置布局，不能给MainWindow设置layout[也就是不能写this->setLayout(vLayout); 或者setLayout(vLayout);]！
    */


    /*---------------学生信息--------------*/
    label_Title = new QLabel("学生信息录入",widget);
    label_Info = new QLabel("基础信息",widget);;
    label_Name = new QLabel("姓名",widget);;
    label_Age = new QLabel("年龄",widget);;
    label_Gen = new QLabel("性别",widget);;
    label_National = new QLabel("民族",widget);;
    label_Address = new QLabel("籍贯",widget);;
    label_Date = new QLabel("出生日期",widget);;
    label_Course = new QLabel("选修课程",widget);;
    label_Comment = new QLabel("个人评价",widget);;
    label_Total_Info = new QLabel("信息汇总",widget);;

    lineEdit_Name = new QLineEdit(widget);
    spinBox_Age = new QSpinBox(widget);
    spinBox_Age->setRange(0,120);

    radioButton_Boy = new QRadioButton("男",widget);
    radioButton_Girl = new QRadioButton("女",widget);;

    comboBox_National = new QComboBox(widget);
    comboBox_National->addItems({"汉族","回族","蒙古族","藏族",});
    comboBox_Province = new QComboBox(widget);
    comboBox_Province->addItems({"陕西省","四川省","陕西省"});
    comboBox_City = new QComboBox(widget);
    comboBox_City->addItems({"西安市","咸阳市","宝鸡市"});

    dateEdit_Date = new QDateEdit(widget);
    dateEdit_Date->setDisplayFormat("yyyy-MM-dd");

    checkBox_All_Choice = new QCheckBox("全选",widget);
    checkBox_C = new QCheckBox("C语言程序设计",widget);
    checkBox_Python = new QCheckBox("Python程序设计",widget);
    checkBox_Cpp = new QCheckBox("C++面向对象程序设计",widget);
    checkBox_Math = new QCheckBox("高等数学",widget);
    checkBox_Computer_English = new QCheckBox("计算机英语",widget);
    checkBox_Computer_Organization = new QCheckBox("计算机组成原理",widget);
    checkBox_Computer_Internet = new QCheckBox("计算机网络",widget);
    checkBox_Struct = new QCheckBox("数据结构",widget);
    checkBox_Databases = new QCheckBox("数据库",widget);
    checkBox_OS = new QCheckBox("操作系统",widget);
    checkBox_Line_Math = new QCheckBox("线性代数",widget);

    textEdit_Comment = new QTextEdit(widget);
    textBrowser_Display = new QTextBrowser(widget);
    pushButton_OK = new QPushButton("确定",widget);
    //分割线QFrame
    line_2 = new QFrame(widget);
    line_2->setFrameShape(QFrame::HLine);
    line_3 = new QFrame(widget);
    line_3->setFrameShape(QFrame::HLine);

    //布局：通过水平和垂直的方法
    QHBoxLayout* hLayout_1 = new QHBoxLayout;
    hLayout_1->addStretch();
    hLayout_1->addWidget(label_Title);
    hLayout_1->addStretch();
    QHBoxLayout* hLayout_2 = new QHBoxLayout;
    hLayout_2->addWidget(label_Info);
    QHBoxLayout* hLayout_3 = new QHBoxLayout;
    hLayout_3->addWidget(label_Name);
    hLayout_3->addWidget(lineEdit_Name);
    hLayout_3->addStretch();
    hLayout_3->addWidget(label_Age);
    hLayout_3->addWidget(spinBox_Age);
    hLayout_3->addStretch();
    hLayout_3->addWidget(label_Gen);
    hLayout_3->addWidget(radioButton_Boy);
    hLayout_3->addWidget(radioButton_Girl);
    hLayout_3->addStretch();
    hLayout_3->addWidget(label_National);
    hLayout_3->addWidget(comboBox_National);
    hLayout_3->addStretch();
    QHBoxLayout* hLayout_4 = new QHBoxLayout;
    hLayout_4->addWidget(label_Address);
    hLayout_4->addWidget(comboBox_Province);
    hLayout_4->addWidget(comboBox_City);
    hLayout_4->addStretch();
    hLayout_4->addWidget(label_Date);
    hLayout_4->addWidget(dateEdit_Date);
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    hLayout_4->addStretch();
    QHBoxLayout* hLayout_5 = new QHBoxLayout;
    hLayout_5->addWidget(label_Course);
    QHBoxLayout* hLayout_6 = new QHBoxLayout;
    hLayout_6->addWidget(checkBox_C);
    hLayout_6->addStretch();
    hLayout_6->addWidget(checkBox_Python);
    hLayout_6->addStretch();
    hLayout_6->addWidget(checkBox_Cpp);
    hLayout_6->addStretch();
    hLayout_6->addWidget(checkBox_Math);
    hLayout_6->addStretch();
    hLayout_6->addWidget(checkBox_Computer_English);
    hLayout_6->addStretch();
    hLayout_6->addWidget(checkBox_Computer_Organization);

    QHBoxLayout* hLayout_7 = new QHBoxLayout;
    hLayout_7->addWidget(checkBox_Computer_Internet);
    hLayout_7->addStretch();
    hLayout_7->addWidget(checkBox_Struct);
    hLayout_7->addStretch();
    hLayout_7->addWidget(checkBox_Databases);
    hLayout_7->addStretch();
    hLayout_7->addWidget(checkBox_OS);
    hLayout_7->addStretch();
    hLayout_7->addWidget(checkBox_Line_Math);
    hLayout_7->addStretch();
    QHBoxLayout* hLayout_8 = new QHBoxLayout;
    hLayout_8->addWidget(checkBox_All_Choice);
    QHBoxLayout* hLayout_9 = new QHBoxLayout;
    hLayout_9->addWidget(label_Comment);
    QHBoxLayout* hLayout_10 = new QHBoxLayout;
    hLayout_10->addStretch();
    hLayout_10->addWidget(textEdit_Comment,1);//拉伸权重1
    hLayout_10->addStretch();
    QHBoxLayout* hLayout_11 = new QHBoxLayout;
    hLayout_11->addStretch();
    hLayout_11->addWidget(pushButton_OK);
    hLayout_11->addStretch();
    QHBoxLayout* hLayout_12 = new QHBoxLayout;
    hLayout_12->addWidget(label_Total_Info);
    QHBoxLayout* hLayout_13 = new QHBoxLayout;
    hLayout_13->addStretch();
    hLayout_13->addWidget(textBrowser_Display,1);//拉伸权重1
    hLayout_13->addStretch();
    QVBoxLayout* vLayout = new QVBoxLayout;
    vLayout->addStretch();
    vLayout->addLayout(hLayout_1);
    vLayout->addStretch();
    vLayout->addWidget(line_2);  // 加入分割线
    vLayout->addLayout(hLayout_2);
    vLayout->addLayout(hLayout_3);
    vLayout->addLayout(hLayout_4);
    vLayout->addLayout(hLayout_5);
    vLayout->addLayout(hLayout_6);
    vLayout->addLayout(hLayout_7);
    vLayout->addLayout(hLayout_8);
    vLayout->addLayout(hLayout_9);
    vLayout->addStretch();
    vLayout->addLayout(hLayout_10);
    vLayout->addStretch();
    vLayout->addLayout(hLayout_11);
    vLayout->addStretch();
    vLayout->addWidget(line_3);  // 加入分割线
    vLayout->addLayout(hLayout_12);
    vLayout->addStretch();
    vLayout->addLayout(hLayout_13);
    vLayout->addStretch();
    widget->setLayout(vLayout);

    setCentralWidget(widget);//设置主窗口的中心部件！！QMainWindow必须这一步
    //4.状态栏 statusBar
    QPushButton* button = new QPushButton("按钮");
    //ui->statusbar->addWidget(button);// 普通addWidget：会被临时消息showMessage覆盖
    ui->statusbar->addPermanentWidget(button);//永久部件，永远显示，不会被showMessage消息冲掉

    /*给计算按钮补充代码:
    connect(button_calc,&QPushButton::clicked,[=](){
        int a = lineEdit_number_1->text().toInt();
        int b = lineEdit_number_2->text().toInt();
        int res = a+b;
        lineEdit_result->setText(QString::number(res));
    });*/

    //给学生管理系统补充代码：
    //手动connect 信号槽
    connect(pushButton_OK,&QPushButton::clicked,this,&MainWindow::pushButton_OK_clicked);
    connect(checkBox_All_Choice,&QCheckBox::clicked,this,&MainWindow::checkBox_All_Choice_clicked);

    connect(checkBox_C,&QCheckBox::clicked,this,&MainWindow::checkBox_C_clicked);
    connect(checkBox_Python,&QCheckBox::clicked,this,&MainWindow::checkBox_Python_clicked);
    connect(checkBox_Cpp,&QCheckBox::clicked,this,&MainWindow::checkBox_Cpp_clicked);
    connect(checkBox_Math,&QCheckBox::clicked,this,&MainWindow::checkBox_Math_clicked);
    connect(checkBox_Computer_English,&QCheckBox::clicked,this,&MainWindow::checkBox_Computer_English_clicked);
    connect(checkBox_Computer_Organization,&QCheckBox::clicked,this,&MainWindow::checkBox_Computer_Organization_clicked);
    connect(checkBox_Computer_Internet,&QCheckBox::clicked,this,&MainWindow::checkBox_Computer_Internet_clicked);
    connect(checkBox_Struct,&QCheckBox::clicked,this,&MainWindow::checkBox_Struct_clicked);
    connect(checkBox_Databases,&QCheckBox::clicked,this,&MainWindow::checkBox_Databases_clicked);
    connect(checkBox_OS,&QCheckBox::clicked,this,&MainWindow::checkBox_OS_clicked);
    connect(checkBox_Line_Math,&QCheckBox::clicked,this,&MainWindow::checkBox_Line_Math_clicked);


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::pushButton_OK_clicked()
{
    //输出姓名
    QString info = label_Info->text();
    textBrowser_Display->append(info);

    QString name = lineEdit_Name->text();
    QString label_name = label_Name->text();
    QString name_total = label_name + ": " + name;
    textBrowser_Display->append(name_total);//追加，不会被覆盖
    //ui->textBrowser_Display->append(name);

    //输出年龄
    QString age = spinBox_Age->text();
    QString label_age = label_Age->text();
    QString age_total = label_age + ": " + age;
    textBrowser_Display->append(age_total);


    //输出性别
    QString gen ;
    if(radioButton_Boy->isChecked())
    {
        gen = "男";
    }
    else
    {
        gen ="女";
    }
    QString label_gen = label_Gen->text();
    QString gen_total = label_gen + ": " + gen;
    textBrowser_Display->append(gen_total);

    //民族
    QString national = comboBox_National->currentText();
    QString label_national = label_National->text();
    QString national_total = label_national + ": " + national;
    textBrowser_Display->append(national_total);

    //籍贯
    QString province = comboBox_Province->currentText();
    QString city = comboBox_City->currentText();
    QString label_address = label_Address->text();
    QString address_total = label_address + ": " + province + city;
    textBrowser_Display->append(address_total);

    //出生日期
    QString date = dateEdit_Date->date().toString("yyyy-MM-dd");
    QString label_date = label_Date->text();
    QString date_total = label_date + ": " + date;
    textBrowser_Display->append(date_total);

    //课程
    QString course;
    if(checkBox_C->isChecked())
    {
        course +="C语言程序设计，";
    }
    if(checkBox_Python->isChecked())
    {
        course +="Python程序设计，";
    }
    if(checkBox_Cpp->isChecked())
    {
        course +="C++面向对象程序设计，";
    }
    if(checkBox_Math->isChecked())
    {
        course +="高等数学，";
    }
    if(checkBox_Computer_English->isChecked())
    {
        course +="计算机英语，";
    }
    if(checkBox_Computer_Organization->isChecked())
    {
        course +="计算机组成原理，";
    }
    if(checkBox_Computer_Internet->isChecked())
    {
        course +="计算机网络，";
    }
    if(checkBox_Struct->isChecked())
    {
        course +="数据结构，";
    }
    if(checkBox_Databases->isChecked())
    {
        course +="数据库，";
    }
    if(checkBox_OS->isChecked())
    {
        course +="操作系统，";
    }
    if(checkBox_Line_Math->isChecked())
    {
        course +="线性代数，";
    }
    QString label_course = label_Course->text();
    QString course_total = label_course + ": " + course;
    textBrowser_Display->append(course_total);


    //个人评价
    QString comment = textEdit_Comment->toPlainText();
    QString label_comment = label_Comment->text();
    QString comment_total = label_comment + ": " + comment;
    textBrowser_Display->append(comment_total);

}


void MainWindow::checkBox_All_Choice_clicked(bool checked)
{
    qDebug()<< "全选框状态：" << checked;
    checkBox_C->setChecked(checked);
    checkBox_Python->setChecked(checked);
    checkBox_Cpp->setChecked(checked);
    checkBox_Math->setChecked(checked);
    checkBox_Computer_English->setChecked(checked);
    checkBox_Computer_Organization->setChecked(checked);
    checkBox_Computer_Internet->setChecked(checked);
    checkBox_Struct->setChecked(checked);
    checkBox_Databases->setChecked(checked);
    checkBox_OS->setChecked(checked);
    checkBox_Line_Math->setChecked(checked);
}

void MainWindow::updateAllCheckState()
{
    bool allChecked = checkBox_C->isChecked()
    && checkBox_Python->isChecked()
        && checkBox_Cpp->isChecked()
        && checkBox_Math->isChecked()
        && checkBox_Computer_English->isChecked()
        && checkBox_Computer_Organization->isChecked()
        && checkBox_Computer_Internet->isChecked()
        && checkBox_Struct->isChecked()
        && checkBox_Databases->isChecked()
        && checkBox_OS->isChecked()
        && checkBox_Line_Math->isChecked();

    checkBox_All_Choice->setChecked(allChecked);
}

void MainWindow::checkBox_C_clicked(bool )
{
    updateAllCheckState();
}


void MainWindow::checkBox_Python_clicked(bool )
{
    updateAllCheckState();
}


void MainWindow::checkBox_Cpp_clicked(bool )
{
    updateAllCheckState();
}


void MainWindow::checkBox_Math_clicked(bool )
{
    updateAllCheckState();
}


void MainWindow::checkBox_Computer_English_clicked(bool )
{
    updateAllCheckState();
}


void MainWindow::checkBox_Computer_Organization_clicked(bool )
{
    updateAllCheckState();
}


void MainWindow::checkBox_Computer_Internet_clicked(bool )
{
    updateAllCheckState();
}


void MainWindow::checkBox_Struct_clicked(bool )
{
    updateAllCheckState();
}


void MainWindow::checkBox_Databases_clicked(bool )
{
    updateAllCheckState();
}


void MainWindow::checkBox_OS_clicked(bool )
{
    updateAllCheckState();
}


void MainWindow::checkBox_Line_Math_clicked(bool )
{
    updateAllCheckState();
}

