#include "dialog.h"
#include "ui_dialog.h"

#include <QFileDialog>
#include <QColorDialog>
Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);

    //1.QFileDialog 文件
    file_dialog_ = new QFileDialog(this);
    connect(file_dialog_,&QFileDialog::fileSelected,this, //用户选中一个文件、点击确定时触发，传出选中文件路径。
        [](const QString& file)
        {
            qDebug() << "选中文件" << file;
        });
    connect(file_dialog_,&QFileDialog::filesSelected,this,//当文件对话框设置为多选模式，用户选多个文件，点确定触发
            [](const QStringList &files)
            {
                qDebug() << "选中多个文件：" << files;
            });
    connect(file_dialog_,&QFileDialog::currentChanged,this,//实时！鼠标点击选中文件，还没点确定，立刻触发。只要点击不同文件就触发。
            [](const QString &path)
            {
                qDebug() << "当前点击选中的文件(未确认):" << path;
            });
    connect(file_dialog_,&QFileDialog::directoryEntered,this,//用户进入新文件夹（双击打开文件夹）就触发，还不用选文件。
            [](const QString &directory)
            {
                qDebug() << "进入目录:" << directory;
            });
    connect(file_dialog_,&QFileDialog::filterSelected,this,//切换文件过滤器：下拉切换文件后缀过滤器（比如`.txt`、`.png`）的时候触发
            [](const QString& filter)
            {
                qDebug() << "filterSelected 过滤器:" << filter;
            });
    connect(file_dialog_,&QFileDialog::rejected,this, //点取消按钮触发
            [](){
                qDebug() << "用户点取消";
            });

    //2.QColorDialog 颜色
    color_dialog_ = new QColorDialog(this);
   /* connect(color_dialog_,&QColorDialog::colorSelected,//点【确定】按钮后触发，最终选定颜色
            [this](const QColor& color)
            {
                int r =color.red();
                int g = color.green();
                int b = color.blue();
                QString sheet = QString(
                                    "background: rgb(%1,%2,%3);")
                                    .arg(r).arg(g).arg(b);
                this->setStyleSheet(sheet);
            });*/
    connect(color_dialog_,&QColorDialog::currentColorChanged,//实时预览，拖动调色板立刻触发
            [this](const QColor& color)
    {
                int r =color.red();
                int g = color.green();
                int b = color.blue();
                QString sheet = QString(
                                    "background: rgb(%1,%2,%3);")
                                    .arg(r).arg(g).arg(b);
                this->setStyleSheet(sheet);
        qDebug() << "currentColorChanged 实时预览颜色：" << color;
    });/*
    connect(color_dialog_,&QColorDialog::accepted,this,
            [](){
                qDebug() << "accepted：用户点击颜色对话框【确定】";//继承来的accepted，点确定触发（和colorSelected几乎同时触发）
            });
    connect(color_dialog_,&QColorDialog::rejected,this,
            [](){
                qDebug() << "rejected：用户点击颜色对话框【取消】";//继承来的rejected，点取消触发
            });
    */
    //3.QFontDialog 字体
    font_dialog_ = new QFontDialog(this);
    font_dialog_->setOption(QFontDialog::DontUseNativeDialog, true); // 关闭Windows原生对话框，开启currentFontChanged实时信号
   /* connect(font_dialog_,&QFontDialog::fontSelected,
            [this](const QFont& font)
            {
                ui->pushButton_color->setFont(font);
            });*/
    connect(font_dialog_,&QFontDialog::currentFontChanged,this,//实时信号，切换字体/字号立刻触发
            [this](const QFont& font)
            {
                ui->pushButton_color->setFont(font);
                qDebug()<<"currentFontChanged 实时字体："<<font.family()<<font.pointSize();//font.family() → QString返回字体族名字;font.pointSize()→int返回字号（磅值 pointSize）
            });

    connect(ui->pushButton_open,&QPushButton::clicked,this,&Dialog::pushButton_open_clicked);
    connect(ui->pushButton_file,&QPushButton::clicked,this,&Dialog::pushButton_file_clicked);
    connect(ui->pushButton_color,&QPushButton::clicked,this,&Dialog::pushButton_color_clicked);
    connect(ui->pushButton_font,&QPushButton::clicked,this,&Dialog::pushButton_font_clicked);
}
Dialog::~Dialog()
{
    delete ui;
}
//1.打开普通 QDialog对话框
void Dialog::pushButton_open_clicked()
{
    QDialog* new_dialog = new QDialog(this);
    new_dialog->resize(300,300);//resize 设置的是控件自身宽高
    new_dialog->setModal(true);//模态对话框，弹出后阻塞父窗口，父窗口不能点击
    new_dialog->show();
}

//2.文件对话框 QFileDialog
void Dialog::pushButton_file_clicked()
{
    /*
   构造函数给file_dialog_绑定了`fileSelected`信号，但这里弹出的是局部新建的对话框，选中文件不会触发你写的 Lambda 打印，这是代码逻辑 bug。
所以注释掉第一行，把file_dialog变量换成file_dialog_就可以了。
   */
    //QFileDialog* file_dialog = new QFileDialog(this);
    file_dialog_->setModal(true);
    file_dialog_->show();
}

//3.颜色对话框 QColorDialog
void Dialog::pushButton_color_clicked()
{
    color_dialog_->setModal(true);
    color_dialog_->show();
}

//4.字体对话框 QFontDialog
void Dialog::pushButton_font_clicked()
{
    font_dialog_->setModal(true);
    font_dialog_->show();

}

//5.QMessageBox 常用静态函数
//信息提示
void Dialog::on_pushButton_message_clicked()
{
    QMessageBox::information(this,"标题","这是一个对话框");
}
//询问
void Dialog::on_pushButton_question_clicked()
{
    auto res =QMessageBox::question(this,"标题","询问：确定要删除吗？");
    if(res == QMessageBox::Yes)
    {
        qDebug() << "用户点了是";
    }
    else
    {
        qDebug() << "用户点了否";
    }
}
//警告
void Dialog::on_pushButton_warning_clicked()
{
    QMessageBox::warning(this,"标题","警告");
}
//严重错误
void Dialog::on_pushButton_critial_clicked()
{
    QMessageBox::critical(this,"标题","严重错误");
}

