#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QFileDialog>
#include <QColorDialog>
#include <QFontDialog>
#include <QMessageBox>
QT_BEGIN_NAMESPACE
namespace Ui {
class Dialog;
}
QT_END_NAMESPACE

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr);
    ~Dialog() override;

private slots:
    void pushButton_open_clicked();

    void pushButton_file_clicked();

    void pushButton_color_clicked();

    void pushButton_font_clicked();

    void on_pushButton_message_clicked();

    void on_pushButton_question_clicked();

    void on_pushButton_warning_clicked();

    void on_pushButton_critial_clicked();

private:
    Ui::Dialog *ui;
    QFileDialog* file_dialog_ = nullptr;
    QColorDialog* color_dialog_ = nullptr;
    QFontDialog* font_dialog_ = nullptr;
};
#endif // DIALOG_H
