#include "shapet.h"

ShapeT::ShapeT(int x, int y,QWidget *parent)
    : Shape(x,y,parent)
{
   Position(x, y);
}

//摆放T字初始形状，只操作4个button
void ShapeT::Position(int x, int y)
{
    //T字形摆放，Size来自父类protected成员，子类直接访问
    button_1_->setGeometry(x, y, Size, Size);
    button_2_->setGeometry(x+Size, y, Size, Size);
    button_3_->setGeometry(x+2*Size, y, Size, Size);
    button_4_->setGeometry(x+Size, y-Size, Size, Size);
}

//T方块旋转，只写Change，Left/Right/Down直接复用父类
void ShapeT::Change()
{
    //你T旋转逻辑，操作四个button_1_~button_4_
    int x_3 = button_3_->x();
    int y_3 = button_3_->y();

    //先记录旋转后四个按钮的（预期坐标），不直接move
    QPoint p1,p2,p4;//旋转的话p3是不动的
    switch(rotateState)
    {
    case 0:
    {
        p1 = QPoint(x_3+Size,y_3);
        p2 = QPoint(x_3,y_3-Size);
        p4 = QPoint(x_3,y_3+Size);
    }
    break;
    case 1:
    {
        p1 = QPoint(x_3,y_3+Size);
        p2 = QPoint(x_3+Size,y_3);
        p4 = QPoint(x_3-Size,y_3);
    }
    break;
    case 2:
    {
        p1 = QPoint(x_3-Size,y_3);
        p2 = QPoint(x_3,y_3+Size);
        p4 = QPoint(x_3,y_3-Size);
    }
    break;
    case 3:
    {
        p1 = QPoint(x_3,y_3-Size);
        p2 = QPoint(x_3-Size,y_3);
        p4 = QPoint(x_3+Size,y_3);
    }
    break;
    default:return;
    }


    //全部4个点：button3不动！检查旋转后是否越界10*20画布
    QPoint pts[] = {p1,p2,p4,QPoint(x_3,y_3)};
    bool outBound = false;
    for(auto pt: pts)
    {
        if(pt.x() < 0 || (pt.x()+ Size) > 10*Size)
        {
            outBound = true;
        }
        if(pt.y() < 0 || (pt.y()+ Size) > 20*Size)
        {
            outBound = true;
        }
    }
    if(outBound)
    {
        //越界，本次旋转直接放弃，rotateState不增加
        return;
    }
    //不越界才真正移动按钮
    button_1_->move(p1);
    button_2_->move(p2);
    button_4_->move(p4);
    rotateState = (rotateState+1)%4;
}