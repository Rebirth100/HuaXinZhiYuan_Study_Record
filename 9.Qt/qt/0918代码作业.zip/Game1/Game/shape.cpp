#include "shape.h"
#include "background.h"
const int Shape::Size = 30; //方块格子大小，所有子类共用
//所有图形共用的左移、右移、下移逻辑在这里写，子类不用写 Left/Right/Down
Shape::Shape(int x, int y, QWidget *parent)
    : QWidget{parent}
{
    //父类构造，创建4个按钮，所有子类共用4个按钮对象
    button_1_ = new QPushButton(parent);
    button_2_ = new QPushButton(parent);
    button_3_ = new QPushButton(parent);
    button_4_ = new QPushButton(parent);
    //统一样式
    button_1_->setStyleSheet(QString::fromUtf8("background-color: rgb(85, 85, 255);"));
    button_2_->setStyleSheet(QString::fromUtf8("background-color: rgb(85, 85, 255);"));
    button_3_->setStyleSheet(QString::fromUtf8("background-color: rgb(85, 85, 255);"));
    button_4_->setStyleSheet(QString::fromUtf8("background-color: rgb(85, 85, 255);"));

}

void Shape::GetFourButtons(QPushButton* &b1, QPushButton* &b2, QPushButton* &b3, QPushButton* &b4)
{
    b1 = button_1_;
    b2 = button_2_;
    b3 = button_3_;
    b4 = button_4_;
}

//====新增：检测向下碰撞
//true=会碰撞（不能下移）；false=可以下移
bool Shape::CheckDownCollision(Background* bg)
{
    QPushButton* btns[] = {button_1_,button_2_,button_3_,button_4_};
    for(auto btn : btns)
    {
        // 当前按钮的网格
        int col = btn->x() / Size;
        int row = btn->y() / Size;
        //向下移动一格后的行
        int nextRow = row + 1;
        //先判断是不是碰画布底部
        if(nextRow >= 20)
        {
            return true;
        }
        //判断网格array[col][nextRow]是否已经存在按钮（已有落定方块）
        if(bg->array[col][nextRow] != nullptr)
        {
            return true;
        }
    }
    return false;
}

//获取四个按钮的最小、最大X/Y
void Shape::getFourBtnRange(int &minX,int &maxX,int &minY,int &maxY)
{
    QPushButton* btns[] = {button_1_,button_2_,button_3_,button_4_};
    minX = btns[0]->x();
    maxX = btns[0]->x() + Size;
    minY = btns[0]->y();
    maxY = btns[0]->y() + Size;
    for(int i = 1; i< 4; i++)
    {
        minX = qMin(minX,btns[i]->x());
        maxX = qMax(maxX,btns[i]->x() + Size);
        minY = qMin(minY,btns[i]->y());
        minY = qMax(maxY,btns[i]->y() + Size);
    }
}

//父类实现左移：全部按钮一起左移Size像素
void Shape::Left()
{
    int minX,maxX,minY,maxY;
    getFourBtnRange(minX,maxX,minY,maxY);
    //边界不能小于0
    if((minX-Size) < 0)
    {
        return;
    }
    InnerLeft(button_1_);
    InnerLeft(button_2_);
    InnerLeft(button_3_);
    InnerLeft(button_4_);
}

void Shape::Right()
{
    int minX,maxX,minY,maxY;
    getFourBtnRange(minX,maxX,minY,maxY);
    //右边不能超过背景总宽：10*Size
    if((maxX + Size) > 10*Size)
    {
        return;
    }

    InnerRight(button_1_);
    InnerRight(button_2_);
    InnerRight(button_3_);
    InnerRight(button_4_);
}

void Shape::Down()
{
    int minX,maxX,minY,maxY;
    getFourBtnRange(minX,maxX,minY,maxY);
    //底部不能超过背景总高20*Size
    if((minY +Size) > 20*Size)
    {
        return;
    }

    InnerDown(button_1_);
    InnerDown(button_2_);
    InnerDown(button_3_);
    InnerDown(button_4_);
}
//工具函数：单个按钮左移
void Shape::InnerLeft(QPushButton* button)
{
    int x = button->x();
    int y = button->y();
    x -=Size;
    button->move(x,y);
}

void Shape::InnerRight(QPushButton* button)
{
    int x = button->x();
    int y = button->y();
    x +=Size;
    button->move(x,y);
}

void Shape::InnerDown(QPushButton* button)
{
    int x = button->x();
    int y = button->y();
    y +=Size;
    button->move(x,y);
}

