#include "background.h"
#include "shape.h"

Background::Background(QWidget *parent)
{
    widget_ = new QWidget(parent);
    int w = Shape::Size*10;
    int h = Shape::Size*20;
    widget_->resize(w,h);
    widget_->setStyleSheet(QString::fromUtf8("background-color:rgb(0,255,255);"));

    //====初始化array全部置空
    for(int c=0;c<10;c++)
    {
        for(int r=0;r<20;r++)
        {
            array[c][r] = nullptr;
        }
    }
}

QWidget* Background::Widget()
{
    return widget_;
}

//把当前shape4个按钮存进网格数组
void Background::StoreShapeToArray(Shape* shape)
{
    QPushButton* b1 = nullptr;
    QPushButton* b2 = nullptr;
    QPushButton* b3 = nullptr;
    QPushButton* b4 = nullptr;
    shape->GetFourButtons(b1,b2,b3,b4);

    QPushButton* btns[] = {b1,b2,b3,b4};
    for(auto btn : btns)
    {
        int col = btn->x() / Shape::Size;
        int row = btn->y() / Shape::Size;
        array[col][row] = btn;
    }
}
