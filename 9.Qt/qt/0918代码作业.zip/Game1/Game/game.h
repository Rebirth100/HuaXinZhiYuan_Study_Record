#ifndef GAME_H
#define GAME_H

#include <QDialog>
class Shape;
class Background;
QT_BEGIN_NAMESPACE
namespace Ui {
class Game;
}
QT_END_NAMESPACE

class Game : public QDialog
{
    Q_OBJECT

public:
    explicit Game(QWidget *parent = nullptr);
    ~Game() override;

private slots:
    void on_pushButton_left_clicked();

    void on_pushButton_change_clicked();

    void on_pushButton_right_clicked();

    void on_pushButton_down_clicked();

private:
    //新增一个成员函数：生成新方块
    void SpawnNewShape();

    Ui::Game *ui;
    Shape* shape_ = nullptr;//父类指针，接收任意子类对象
    Background* background_ = nullptr;
};
#endif // GAME_H
