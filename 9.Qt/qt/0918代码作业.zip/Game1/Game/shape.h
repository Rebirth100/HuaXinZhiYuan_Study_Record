#ifndef SHAPE_H
#define SHAPE_H
#include <QPushButton>
#include <QWidget>
//前置声明Background
class Background;

class Shape : public QWidget
{
    Q_OBJECT
public:
    explicit Shape(int x, int y, QWidget *parent);

    //公共移动逻辑，全部放在父类，子类直接继承复用
    void Left();
    void Down();
    void Right();

    //检测向下是否碰撞（背景的array网格），background传进来
    bool CheckDownCollision(Background* bg);
    //添加 public 接口，获取四个按钮指针
    void GetFourButtons(QPushButton* &b1, QPushButton* &b2, QPushButton* &b3, QPushButton* &b4);

    //纯虚函数，【子类必须实现】：旋转、设置4个按钮相对位置
    virtual void Change() = 0;
protected:
    virtual void Position(int x, int y) = 0;
    //工具函数：父类实现，子类直接调用，不用重复写
    void InnerLeft(QPushButton* button);
    void InnerRight(QPushButton* button);
    void InnerDown(QPushButton* button);

    //边界辅助函数
    void getFourBtnRange(int &minX,int &maxX,int &minY,int &maxY);

signals:
public:
    static const int Size;
protected:
    QPushButton* button_1_ = nullptr;
    QPushButton* button_2_ = nullptr;
    QPushButton* button_3_ = nullptr;
    QPushButton* button_4_ = nullptr;
};

#endif // SHAPE_H
