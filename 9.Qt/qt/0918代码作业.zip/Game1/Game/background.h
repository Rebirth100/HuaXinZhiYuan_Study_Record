#ifndef BACKGROUND_H
#define BACKGROUND_H

#include <QWidget>
#include <QPushButton>
//前置声明
class Shape;
class Background
{
public:
    explicit Background(QWidget *parent = nullptr);

    QWidget* Widget();
    //把shape的4个按钮保存到array网格中（方块落定）
    void StoreShapeToArray(Shape* shape);

public:
    //改成public，给Shape访问
    QPushButton* array[10][20];
signals:
private:
    QWidget* widget_ = nullptr;

};

#endif // BACKGROUND_H
