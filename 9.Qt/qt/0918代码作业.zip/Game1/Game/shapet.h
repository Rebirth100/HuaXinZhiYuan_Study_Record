#ifndef SHAPET_H
#define SHAPET_H

#include "shape.h"

class ShapeT : public Shape
{
    Q_OBJECT
public:
    explicit ShapeT(int x,int y,QWidget *parent);

    //子类：只需要实现纯虚函数
    /*
       1. Position：把 4 个按钮摆放成 T 字形；
       2. Change：旋转逻辑；
           Left/Right/Down 完全继承父类，不用写！
    */
    virtual void Change() override;
protected:
    virtual void Position(int x,int y) override;


private:
    int rotateState = 0;//记录旋转状态0‑3
};

#endif // SHAPET_H
