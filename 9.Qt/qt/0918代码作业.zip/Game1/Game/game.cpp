#include "game.h"
#include "ui_game.h"
#include "shape.h"
#include "shapet.h" //（俄罗斯格子是T型）必须引入ShapeT头文件，否则new ShapeT报错
#include "background.h"

Game::Game(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Game)
{
    ui->setupUi(this);
    background_ = new Background(this);
    SpawnNewShape();//调用生成新方块
}

Game::~Game()
{
    delete ui;
}
//生成新T方块
void Game::SpawnNewShape()
{
    //释放旧shape对象（按钮会自动释放，因为parent）
    if(shape_ != nullptr)
    {
        //不要手动delete按钮，按钮parent是background_->Widget()，旧shape析构不会删除按钮；
        delete shape_;
    }
    //起始位置：4*Size横向，Size纵向
    shape_ = new ShapeT(4*Shape::Size,Shape::Size,background_->Widget());
}

//按钮点击，调用Left，会自动执行父类Left
void Game::on_pushButton_left_clicked()
{
    shape_->Left();
}

void Game::on_pushButton_right_clicked()
{
    shape_->Right();
}

void Game::on_pushButton_down_clicked()
{
    //检测向下是否碰撞（碰底 / 碰已有方块）
    bool collide = shape_->CheckDownCollision(background_);
    if(collide)
    {
        //碰撞：当前方块固化存入网格
        background_->StoreShapeToArray(shape_);
        //生成新方块
        SpawnNewShape();
    }
    else
    {
        //不碰撞，正常下移
        shape_->Down();
    }
}

void Game::on_pushButton_change_clicked()
{
    shape_->Change();//自动调用子类ShapeT的Change()
}





