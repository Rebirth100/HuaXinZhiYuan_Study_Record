#include "student.h"
#include "ui_student.h"
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QFormLayout>
#include <QDebug>

Student::Student(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Student)
{
    ui->setupUi(this);

    //固定窗口大小，绝对定位
    this->setFixedSize(950,720);
    this->setWindowTitle("学生信息录入");

    //================ SQLite数据库初始化 =================
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("student.db");
    if(!db.open())
    {
        qDebug()<<"数据库打开失败："<< db.lastError().text();
    }
    else
    {
        QSqlQuery query(db);
        QString createSql = R"(
        CREATE TABLE IF NOT EXISTS StudentInfo(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            age INTEGER,
            gender TEXT,
            nation TEXT,
            address TEXT,
            birthday TEXT,
            course TEXT,
            comment TEXT
        );
        )";
        query.exec(createSql);
        if(query.lastError().isValid())
        {
            qDebug()<<"建表错误："<< query.lastError().text();
        }
    }

    // ========== 创建控件 + setGeometry(x,y,w,h) ==========
    label_Title = new QLabel("学生信息录入", this);
    label_Title->setGeometry(350,10,220,35);

    label_Info = new QLabel("基础信息", this);
    label_Info->setGeometry(20,60,100,25);

    // 姓名
    label_Name = new QLabel("姓名", this);
    label_Name->setGeometry(20,95,50,25);
    lineEdit_Name = new QLineEdit(this);
    lineEdit_Name->setGeometry(70,95,120,25);

    //年龄
    label_Age = new QLabel("年龄", this);
    label_Age->setGeometry(220,95,50,25);
    spinBox_Age = new QSpinBox(this);
    spinBox_Age->setRange(0,120);
    spinBox_Age->setGeometry(270,95,80,25);

    //性别
    label_Gen = new QLabel("性别", this);
    label_Gen->setGeometry(380,95,50,25);
    radioButton_Boy = new QRadioButton("男",this);
    radioButton_Boy->setGeometry(430,95,50,25);
    radioButton_Girl = new QRadioButton("女",this);
    radioButton_Girl->setGeometry(480,95,50,25);

    //民族
    label_National = new QLabel("民族", this);
    label_National->setGeometry(550,95,50,25);
    comboBox_National = new QComboBox(this);
    comboBox_National->addItems({"汉族","回族","蒙古族","藏族"});
    comboBox_National->setGeometry(600,95,120,25);

    //籍贯、出生日期
    label_Address = new QLabel("籍贯", this);
    label_Address->setGeometry(20,135,50,25);
    comboBox_Province = new QComboBox(this);
    comboBox_Province->addItems({"陕西","北京","上海","广东"});
    comboBox_Province->setGeometry(70,135,100,25);
    comboBox_City = new QComboBox(this);
    comboBox_City->addItems({"西安","咸阳","宝鸡"});
    comboBox_City->setGeometry(180,135,100,25);

    label_Date = new QLabel("出生日期", this);
    label_Date->setGeometry(320,135,80,25);
    dateEdit_Date = new QDateEdit(this);
    dateEdit_Date->setDisplayFormat("yyyy-MM-dd");
    dateEdit_Date->setGeometry(400,135,140,25);

    //分割线
    line_2 = new QFrame(this);
    line_2->setFrameShape(QFrame::HLine);
    line_2->setGeometry(20,175,900,3);

    //课程标题
    label_Course = new QLabel("选修课程", this);
    label_Course->setGeometry(20,190,100,25);

    //第一行课程复选框
    checkBox_C = new QCheckBox("C语言程序设计",this);
    checkBox_C->setGeometry(20,220,140,25);
    checkBox_Python = new QCheckBox("Python程序设计",this);
    checkBox_Python->setGeometry(170,220,140,25);
    checkBox_Cpp = new QCheckBox("C++面向对象程序设计",this);
    checkBox_Cpp->setGeometry(320,220,160,25);
    checkBox_Math = new QCheckBox("高等数学",this);
    checkBox_Math->setGeometry(490,220,100,25);
    checkBox_Computer_English = new QCheckBox("计算机英语",this);
    checkBox_Computer_English->setGeometry(600,220,110,25);
    checkBox_Computer_Organization = new QCheckBox("计算机组成原理",this);
    checkBox_Computer_Organization->setGeometry(720,220,140,25);

    //第二行课程
    checkBox_Computer_Internet = new QCheckBox("计算机网络",this);
    checkBox_Computer_Internet->setGeometry(20,255,110,25);
    checkBox_Struct = new QCheckBox("数据结构",this);
    checkBox_Struct->setGeometry(140,255,100,25);
    checkBox_Databases = new QCheckBox("数据库",this);
    checkBox_Databases->setGeometry(250,255,90,25);
    checkBox_OS = new QCheckBox("操作系统",this);
    checkBox_OS->setGeometry(350,255,100,25);
    checkBox_Line_Math = new QCheckBox("线性代数",this);
    checkBox_Line_Math->setGeometry(460,255,110,25);

    //全选
    checkBox_All_Choice = new QCheckBox("全选",this);
    checkBox_All_Choice->setGeometry(20,290,80,25);

    //个人评价
    label_Comment = new QLabel("个人评价", this);
    label_Comment->setGeometry(20,320,100,25);
    textEdit_Comment = new QTextEdit(this);
    textEdit_Comment->setGeometry(20,345,900,80);

    //确定、清空按钮
    pushButton_OK = new QPushButton("确定",this);
    pushButton_OK->setGeometry(400,440,120,35);

    pushButton_Clear = new QPushButton("清空表单",this);
    pushButton_Clear->setGeometry(550,440,120,35);

    //分割线
    line_3 = new QFrame(this);
    line_3->setFrameShape(QFrame::HLine);
    line_3->setGeometry(20,490,900,3);

    //信息汇总
    label_Total_Info = new QLabel("信息汇总", this);
    label_Total_Info->setGeometry(20,505,100,25);
    textBrowser_Display = new QTextBrowser(this);
    textBrowser_Display->setGeometry(20,530,900,160);

    //手动connect 信号槽
    connect(pushButton_OK,&QPushButton::clicked,this,&Student::pushButton_OK_clicked);
    connect(pushButton_Clear,&QPushButton::clicked,this,&Student::pushButton_Clear_clicked);

    connect(checkBox_All_Choice,&QCheckBox::clicked,this,&Student::checkBox_All_Choice_clicked);
    connect(checkBox_C,&QCheckBox::clicked,this,&Student::checkBox_C_clicked);
    connect(checkBox_Python,&QCheckBox::clicked,this,&Student::checkBox_Python_clicked);
    connect(checkBox_Cpp,&QCheckBox::clicked,this,&Student::checkBox_Cpp_clicked);
    connect(checkBox_Math,&QCheckBox::clicked,this,&Student::checkBox_Math_clicked);
    connect(checkBox_Computer_English,&QCheckBox::clicked,this,&Student::checkBox_Computer_English_clicked);
    connect(checkBox_Computer_Organization,&QCheckBox::clicked,this,&Student::checkBox_Computer_Organization_clicked);
    connect(checkBox_Computer_Internet,&QCheckBox::clicked,this,&Student::checkBox_Computer_Internet_clicked);
    connect(checkBox_Struct,&QCheckBox::clicked,this,&Student::checkBox_Struct_clicked);
    connect(checkBox_Databases,&QCheckBox::clicked,this,&Student::checkBox_Databases_clicked);
    connect(checkBox_OS,&QCheckBox::clicked,this,&Student::checkBox_OS_clicked);
    connect(checkBox_Line_Math,&QCheckBox::clicked,this,&Student::checkBox_Line_Math_clicked);
}

Student::~Student()
{
    delete ui;
}

void Student::pushButton_OK_clicked()
{
    QString name = lineEdit_Name->text();
    //简单校验：姓名为空直接返回，不保存
    if(name.trimmed().isEmpty())
    {
        qDebug()<<"姓名不能为空！";
        return;
    }

    //=====界面展示逻辑=====
    textBrowser_Display->append("----------新学生信息----------");
    QString label_name = label_Name->text();
    QString name_total = label_name + ": " + name;
    textBrowser_Display->append(name_total);

    QString age = spinBox_Age->text();
    QString label_age = label_Age->text();
    QString age_total = label_age + ": " + age;
    textBrowser_Display->append(age_total);

    QString gen ;
    if(radioButton_Boy->isChecked())
    {
        gen = "男";
    }
    else
    {
        gen ="女";
    }
    QString label_gen = label_Gen->text();
    QString gen_total = label_gen + ": " + gen;
    textBrowser_Display->append(gen_total);

    QString national = comboBox_National->currentText();
    QString label_national = label_National->text();
    QString national_total = label_national + ": " + national;
    textBrowser_Display->append(national_total);

    QString province = comboBox_Province->currentText();
    QString city = comboBox_City->currentText();
    QString label_address = label_Address->text();
    QString address_total = label_address + ": " + province + city;
    textBrowser_Display->append(address_total);

    QString date = dateEdit_Date->date().toString("yyyy-MM-dd");
    QString label_date = label_Date->text();
    QString date_total = label_date + ": " + date;
    textBrowser_Display->append(date_total);

    QString course;
    if(checkBox_C->isChecked()) course +="C语言程序设计，";
    if(checkBox_Python->isChecked()) course +="Python程序设计，";
    if(checkBox_Cpp->isChecked()) course +="C++面向对象程序设计，";
    if(checkBox_Math->isChecked()) course +="高等数学，";
    if(checkBox_Computer_English->isChecked()) course +="计算机英语，";
    if(checkBox_Computer_Organization->isChecked()) course +="计算机组成原理，";
    if(checkBox_Computer_Internet->isChecked()) course +="计算机网络，";
    if(checkBox_Struct->isChecked()) course +="数据结构，";
    if(checkBox_Databases->isChecked()) course +="数据库，";
    if(checkBox_OS->isChecked()) course +="操作系统，";
    if(checkBox_Line_Math->isChecked()) course +="线性代数，";

    QString label_course = label_Course->text();
    QString course_total = label_course + ": " + course;
    textBrowser_Display->append(course_total);

    QString comment = textEdit_Comment->toPlainText();
    QString label_comment = label_Comment->text();
    QString comment_total = label_comment + ": " + comment;
    textBrowser_Display->append(comment_total);

    //========SQLite插入数据库========
    QSqlDatabase db = QSqlDatabase::database();
    QSqlQuery query(db);
    QString stuId = QString::number(QDateTime::currentMSecsSinceEpoch());

    query.prepare(R"(INSERT INTO StudentInfo
    (name,age,gender,nation,address,birthday,course,comment)
    VALUES(:name,:age,:gender,:nation,:address,:birthday,:course,:comment))");

    query.bindValue(":name",name);
    query.bindValue(":age",spinBox_Age->value());
    query.bindValue(":gender",gen);
    query.bindValue(":nation",national);
    query.bindValue(":address",province+city);
    query.bindValue(":birthday",date);
    query.bindValue(":course",course);
    query.bindValue(":comment",comment);

    if(!query.exec())
    {
        qDebug()<<"插入数据库失败："<<query.lastError().text();
    }
    else
    {
        qDebug()<<"✅学生信息保存成功到SQLite";
    }
}

//清空表单槽函数
void Student::pushButton_Clear_clicked()
{
    lineEdit_Name->clear();
    spinBox_Age->setValue(0);

    //清空单选框
    radioButton_Boy->setAutoExclusive(false);
    radioButton_Boy->setChecked(false);
    radioButton_Girl->setChecked(false);
    radioButton_Boy->setAutoExclusive(true);

    comboBox_National->setCurrentIndex(0);
    comboBox_Province->setCurrentIndex(0);
    comboBox_City->setCurrentIndex(0);

    dateEdit_Date->setDate(QDate::currentDate());

    //全部课程取消勾选
    checkBox_C->setChecked(false);
    checkBox_Python->setChecked(false);
    checkBox_Cpp->setChecked(false);
    checkBox_Math->setChecked(false);
    checkBox_Computer_English->setChecked(false);
    checkBox_Computer_Organization->setChecked(false);
    checkBox_Computer_Internet->setChecked(false);
    checkBox_Struct->setChecked(false);
    checkBox_Databases->setChecked(false);
    checkBox_OS->setChecked(false);
    checkBox_Line_Math->setChecked(false);
    checkBox_All_Choice->setChecked(false);

    textEdit_Comment->clear();
}

void Student::checkBox_All_Choice_clicked(bool checked)
{
    qDebug()<< "全选框状态：" << checked;
    checkBox_C->setChecked(checked);
    checkBox_Python->setChecked(checked);
    checkBox_Cpp->setChecked(checked);
    checkBox_Math->setChecked(checked);
    checkBox_Computer_English->setChecked(checked);
    checkBox_Computer_Organization->setChecked(checked);
    checkBox_Computer_Internet->setChecked(checked);
    checkBox_Struct->setChecked(checked);
    checkBox_Databases->setChecked(checked);
    checkBox_OS->setChecked(checked);
    checkBox_Line_Math->setChecked(checked);
}

void Student::updateAllCheckState()
{
    bool allChecked = checkBox_C->isChecked()
    && checkBox_Python->isChecked()
        && checkBox_Cpp->isChecked()
        && checkBox_Math->isChecked()
        && checkBox_Computer_English->isChecked()
        && checkBox_Computer_Organization->isChecked()
        && checkBox_Computer_Internet->isChecked()
        && checkBox_Struct->isChecked()
        && checkBox_Databases->isChecked()
        && checkBox_OS->isChecked()
        && checkBox_Line_Math->isChecked();
    checkBox_All_Choice->setChecked(allChecked);
}

void Student::checkBox_C_clicked(bool ){ updateAllCheckState(); }
void Student::checkBox_Python_clicked(bool ){ updateAllCheckState(); }
void Student::checkBox_Cpp_clicked(bool ){ updateAllCheckState(); }
void Student::checkBox_Math_clicked(bool ){ updateAllCheckState(); }
void Student::checkBox_Computer_English_clicked(bool ){ updateAllCheckState(); }
void Student::checkBox_Computer_Organization_clicked(bool ){ updateAllCheckState(); }
void Student::checkBox_Computer_Internet_clicked(bool ){ updateAllCheckState(); }
void Student::checkBox_Struct_clicked(bool ){ updateAllCheckState(); }
void Student::checkBox_Databases_clicked(bool ){ updateAllCheckState(); }
void Student::checkBox_OS_clicked(bool ){ updateAllCheckState(); }
void Student::checkBox_Line_Math_clicked(bool ){ updateAllCheckState(); }
