#include "dialog.h"
#include "ui_dialog.h"
#include <QDebug>
#include <QSqlQuery>     //执行sql语句类
#include <QSqlDatabase>  //数据库连接类
Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);
    //1. 指定使用SQLite数据库驱动
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    //设置数据库文件名：My0625.db，会生成在程序运行目录下
    db.setDatabaseName("My0625.db");
    //打开数据库；文件不存在SQLite会自动创建这个db文件
    db.open();
    //db.close();

    // 创建查询对象，绑定db连接
    QSqlQuery query(db);

    //2.建表SQL：Student表
    QString sql_create_table="CREATE TABLE Student ("
                             "Id   TEXT    PRIMARY KEY"
                             "              NOT NULL,"
                             "Name TEXT,"
                             "Age  INTEGER"
                              ");";
    query.exec(sql_create_table);//执行建表

    //3.第一条插入
    QString sql_insert ="INSERT INTO Student (Id,Name,Age)"
        "VALUES ("
        " '10001',"
        "  '侯超',"
        "  '18' "
         ");";
    query.exec(sql_insert);

    //4.第二种插入方式：QString::arg拼接字符串
    QString sql_insert_2 = QString("INSERT INTO Student (Id,Name,Age) VALUES"
                               "('%1','%2','%3');").arg("10002").arg("刘栖沅").arg("18");
    query.exec(sql_insert_2);

    //5.查询全部记录
    QString sql_select("select*from Student");
    query.exec(sql_select);

    //遍历结果集，query.next()下移一行，返回true代表还有下一行数据
    while(query.next())
    {
        qDebug() << query.value(0).toString();//第0列 Id
        qDebug() << query.value(1).toString();//第1列 Name
        qDebug() << query.value(2).toInt();//第2列 Age
    }
    //qDebug() << "Drivers=" << QSqlDatabase::drivers();

}

Dialog::~Dialog()
{
    delete ui;
}
