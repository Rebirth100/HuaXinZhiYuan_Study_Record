#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButton_number_1_clicked()
{
    int num = 1;
    //判断当前状态
    if(state_ == Begin)
    {
        //根据当前状态做处理，可能什么也不做
        first_number_ = 1;
        num = first_number_;
        //是否改变当前状态
        state_ = First_number;
    }
    else if(state_ == First_number)
    {
        first_number_ *= 10;
        first_number_ += 1;
        num = first_number_;
    }
    else if(state_ == Operation)
    {
        second_number_ = 1;
        num = second_number_;

        state_ = Second_number;
    }
    else if(state_ ==Second_number)
    {
        second_number_ *= 10;
        second_number_ += 1;
        num = second_number_;
    }
    else if(state_ == Equal)
    {
        return;
    }
    else if(state_ ==Result)
    {
        return;
    }

    ui->lineEdit_display->setText(QString::number(num));
}


void Widget::on_pushButton_number_2_clicked()
{

    int num = 2;
    //判断当前状态
    if(state_ == Begin)
    {
        //根据当前状态做处理，可能什么也不做
        first_number_ = 2;
        num = first_number_;
        //是否改变当前状态
        state_ = First_number;
    }
    else if(state_ == First_number)
    {
        first_number_ *= 10;
        first_number_ += 2;
        num = first_number_;
    }
    else if(state_ == Operation)
    {
        second_number_ = 2;
        num = second_number_;

        state_ = Second_number;
    }
    else if(state_ ==Second_number)
    {
        second_number_ *= 10;
        second_number_ += 2;
        num = second_number_;
    }
    else if(state_ == Equal)
    {
        return;
    }
    else if(state_ ==Result)
    {
        return;
    }

    ui->lineEdit_display->setText(QString::number(num));
}

//等号
void Widget::on_pushButton_number_equal_clicked()
{
    int result = 0;
    //判断当前状态
    if(state_ == Begin)
    {
        return;
    }
    else if(state_ == First_number)
    {
        return;
    }
    else if(state_ == Operation)
    {
        return;
    }
    else if(state_ == Second_number)
    {
        if(op_ == '+')
        {
            result = first_number_ + second_number_;
        }
        else if(op_ == '-')
        {
            result = first_number_ - second_number_;
        }
        else if(op_ == '*')
        {
            result = first_number_ * second_number_;
        }
        else if(op_ == '/')
        {
            if(second_number_ == 0)
            {
                ui->lineEdit_display->setText("error");
                state_ = Equal;
                return;
            }
            result = first_number_ / second_number_;
        }
        state_ = Equal;
    }
    else if(state_ == Equal)
    {
        return;
    }
    else if(state_ ==Result)
    {
        return;
    }
    ui->lineEdit_display->setText(QString::number(result));
}

//加法
void Widget::on_pushButton_number_add_clicked()
{
    if(state_ == Begin)
    {
        return;
    }
    else if(state_ == First_number)
    {
        op_ = '+';
        state_ = Operation;
    }
    else if(state_ == Operation)
    {
        return;
    }
    else if(state_ ==Second_number)
    {
        return;
    }
    else if(state_ == Equal)
    {
        return;
    }
    else if(state_ ==Result)
    {
        return;
    }
}

//减法
void Widget::on_pushButton_number_sub_clicked()
{
    if(state_ == Begin)
    {
        return;
    }
    else if(state_ == First_number)
    {
        op_ = '-';
        state_ = Operation;
    }
    else if(state_ == Operation)
    {
        return;
    }
    else if(state_ ==Second_number)
    {
        return;
    }
    else if(state_ == Equal)
    {
        return;
    }
    else if(state_ ==Result)
    {
        return;
    }
}

//乘法
void Widget::on_pushButton_number_mul_clicked()
{
    if(state_ == Begin)
    {
        return;
    }
    else if(state_ == First_number)
    {
        op_ = '*';
        state_ = Operation;
    }
    else if(state_ == Operation)
    {
        return;
    }
    else if(state_ ==Second_number)
    {
        return;
    }
    else if(state_ == Equal)
    {
        return;
    }
    else if(state_ ==Result)
    {
        return;
    }
}

//除法
void Widget::on_pushButton_number_div_clicked()
{
    if(state_ == Begin)
    {
        return;
    }
    else if(state_ == First_number)
    {
        op_ = '/';
        state_ = Operation;
    }
    else if(state_ == Operation)
    {
        return;
    }
    else if(state_ ==Second_number)
    {
        return;
    }
    else if(state_ == Equal)
    {
        return;
    }
    else if(state_ ==Result)
    {
        return;
    }
}


void Widget::on_pushButton_number_clear_clicked()
{
    //重置所有变量
    state_=Begin;
    first_number_ = 0;
    second_number_ = 0;
    op_ = 0;
    //清空输入框
    ui->lineEdit_display->clear();
}

