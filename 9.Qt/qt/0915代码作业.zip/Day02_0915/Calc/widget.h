#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget() override;

private slots:
    void on_pushButton_number_1_clicked();

    void on_pushButton_number_2_clicked();

    void on_pushButton_number_equal_clicked();

    void on_pushButton_number_add_clicked();

    void on_pushButton_number_sub_clicked();

    void on_pushButton_number_mul_clicked();

    void on_pushButton_number_div_clicked();

    void on_pushButton_number_clear_clicked();

private:
    enum State
    {
        Begin,
        First_number,
        Operation,
        Second_number,
        Equal,
        Result = Equal,
    };
private:
    Ui::Widget *ui;
    State state_ = Begin;

    int first_number_ = 0;
    int second_number_ = 0;
    //保存运算符：+-*/
    char op_ = 0;
};
#endif // WIDGET_H
