#ifndef STUDENT_H
#define STUDENT_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui {
class Student;
}
QT_END_NAMESPACE

class Student : public QWidget
{
    Q_OBJECT

public:
    explicit Student(QWidget *parent = nullptr);
    ~Student() override;

private slots:
    void on_pushButton_OK_clicked();

    void on_checkBox_All_Choice_toggled(bool checked);
private:
    Ui::Student *ui;
};
#endif // STUDENT_H
