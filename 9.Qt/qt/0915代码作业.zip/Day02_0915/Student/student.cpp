#include "student.h"
#include "ui_student.h"

Student::Student(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Student)
{
    ui->setupUi(this);
}

Student::~Student()
{
    delete ui;
}

void Student::on_pushButton_OK_clicked()
{
    //输出姓名
    QString name = ui->lineEdit_Name->text();
    QString label_name = ui->label_Name->text();
    QString name_total = label_name + ": " + name;
    ui->textBrowser_Display->append(name_total);//追加，不会被覆盖
    //ui->textBrowser_Display->append(name);

    //输出年龄
    QString age = ui->spinBox_Age->text();
    QString label_age = ui->label_Age->text();
    QString age_total = label_age + ": " + age;
    ui->textBrowser_Display->append(age_total);


    //输出性别
    QString gen ;
    if(ui->radioButton_Boy->isChecked())
    {
        gen = "男";
    }
    else
    {
        gen ="女";
    }
    QString label_gen = ui->label_Gen->text();
    QString gen_total = label_gen + ": " + gen;
    ui->textBrowser_Display->append(gen_total);

    //民族
    QString national = ui->comboBox_National->currentText();
    QString label_national = ui->label_National->text();
    QString national_total = label_national + ": " + national;
    ui->textBrowser_Display->append(national_total);

    //籍贯
    QString province = ui->comboBox_Province->currentText();
    QString city = ui->comboBox_City->currentText();
    QString label_address = ui->label_Address->text();
    QString address_total = label_address + ": " + province + city;
    ui->textBrowser_Display->append(address_total);

    //出生日期
    QString date = ui->dateEdit_Date->date().toString("yyyy-MM-dd");
    QString label_date = ui->label_Date->text();
    QString date_total = label_date + ": " + date;
    ui->textBrowser_Display->append(date_total);

    //课程
    QString course;
    if(ui->checkBox_C->isChecked())
    {
        course +="C语言程序设计，";
    }
    if(ui->checkBox_Python->isChecked())
    {
        course +="Python程序设计，";
    }
    if(ui->checkBox_Cpp->isChecked())
    {
        course +="C++面向对象程序设计，";
    }
    if(ui->checkBox_Math->isChecked())
    {
        course +="高等数学，";
    }
    if(ui->checkBox_Computer_English->isChecked())
    {
        course +="计算机英语，";
    }
    if(ui->checkBox_Computer_Organization->isChecked())
    {
        course +="计算机组成原理，";
    }
    if(ui->checkBox_Computer_Internet->isChecked())
    {
        course +="计算机网络，";
    }
    if(ui->checkBox_Struct->isChecked())
    {
        course +="数据结构，";
    }
    if(ui->checkBox_Databases->isChecked())
    {
        course +="数据库，";
    }
    if(ui->checkBox_OS->isChecked())
    {
        course +="操作系统，";
    }
    if(ui->checkBox_Line_Math->isChecked())
    {
        course +="线性代数，";
    }
    QString label_course = ui->label_Course->text();
    QString course_total = label_course + ": " + course;
    ui->textBrowser_Display->append(course_total);


    //个人评价
    QString comment = ui->textEdit_Comment->toPlainText();
    QString label_comment = ui->label_Comment->text();
    QString comment_total = label_comment + ": " + comment;
    ui->textBrowser_Display->append(comment_total);

}

//操作界面：点击界面上的全选，自动把所有课程复选框打上勾/取消勾
void Student::on_checkBox_All_Choice_toggled(bool checked)
{
    ui->checkBox_C->setChecked(checked);
    ui->checkBox_Python->setChecked(checked);
    ui->checkBox_Cpp->setChecked(checked);
    ui->checkBox_Math->setChecked(checked);
    ui->checkBox_Computer_English->setChecked(checked);
    ui->checkBox_Computer_Organization->setChecked(checked);
    ui->checkBox_Computer_Internet->setChecked(checked);
    ui->checkBox_Struct->setChecked(checked);
    ui->checkBox_Databases->setChecked(checked);
    ui->checkBox_OS->setChecked(checked);
    ui->checkBox_Line_Math->setChecked(checked);
}



