#include "myshape.h"
#include <QPainter>
#include <QPolygon>

#include <cmath>
myshape::myshape()
{
    width = 3;
    color = Qt::black;//默认黑色
}

// -------- 1.直线 --------
void MyLine::draw(QPainter *painter)
{
    QPen pen;
    pen.setWidth(width);
    pen.setColor(color);
    painter->setPen(pen);
    //painter 就是外面传进来的画家，在这里执行真正绘图
    painter->drawLine(begin, end);
}

// -------- 2.矩形 --------
void MyRect::draw(QPainter *painter)
{
    QPen pen;
    pen.setWidth(width);
    pen.setColor(color);
    painter->setPen(pen);

    int x1 = qMin(begin.x(), end.x());
    int x2 = qMax(begin.x(), end.x());
    int y1 = qMin(begin.y(), end.y());
    int y2 = qMax(begin.y(), end.y());

    painter->drawRect(QRect(x1,y1, x2-x1, y2-y1));
}

// --------3.等腰三角形 --------
void MyTriangle::draw(QPainter *painter)
{
    QPen pen;
    pen.setWidth(width);
    pen.setColor(color);
    painter->setPen(pen);

    int x1 = qMin(begin.x(), end.x());
    int x2 = qMax(begin.x(), end.x());
    int y1 = qMin(begin.y(), end.y());
    int y2 = qMax(begin.y(), end.y());

    QPoint top((x1+x2)/2, y1);
    QPoint leftBot(x1, y2);
    QPoint rightBot(x2, y2);

    QPoint tri[3] = {top, leftBot, rightBot};
    painter->drawPolygon(tri,3);
}

// --------4.五角星 --------
void MyStar::draw(QPainter *painter)
{
    QPen pen
        ;
    pen
        .setWidth(width);
    pen
        .setColor(color);
    painter
        ->setPen(pen);
    painter
        ->setBrush(Qt::NoBrush);

    int x1 = qMin(begin.x(), end.x());
    int x2 = qMax(begin.x(), end.x());
    int y1 = qMin(begin.y(), end.y());
    int y2 = qMax(begin.y(), end.y());

    double cx = (x1 + x2) / 2.0;
    double cy = (y1 + y2) / 2.0;

    // 关键：取短边做直径，保持正五角星比例，不被包围框拉扁
    double R = qMin(x2 - x1, y2 - y1) / 2.0 * 0.95;
    double r = R * 0.38197;

    QPolygon poly
        ;

    for (int i = 0; i < 5; ++i)
    {
        // 外顶点
        double outerAngle = 2.0 * M_PI / 5.0 * i - M_PI / 2.0;
        int px = cx + R * cos(outerAngle);
        int py = cy + R * sin(outerAngle);
        poly
            .append(QPoint(px, py));

        // 内顶点
        double innerAngle = outerAngle + M_PI / 5.0;
        int px2 = cx + r * cos(innerAngle);
        int py2 = cy + r * sin(innerAngle);
        poly
            .append(QPoint(px2, py2));
    }

    painter
        ->drawPolygon(poly);
}

// --------5.向右箭头--------
void MyArrow::draw(QPainter *painter)
{
    QPen pen;
    pen.setWidth(width);
    pen.setColor(color);
    painter->setPen(pen);
    painter->setBrush(Qt::NoBrush);

    int x1 = begin.x();
    int x2 = end.x();
    int y1 = begin.y();
    int y2 = end.y();

    int leftX = qMin(x1, x2);
    int rightX = qMax(x1, x2);
    int topY = qMin(y1, y2);
    int bottomY = qMax(y1, y2);

    int midY = (topY + bottomY) / 2;
    int h = (bottomY - topY) / 2;

    // 拖拽距离太小时，给一个最小尺寸，避免看不见
    if (rightX - leftX < 20) rightX = leftX + 20;
    if (h < 8) h = 8;

    bool toRight = (x2 >= x1);

    QPolygon arr;

    if (toRight)
    {
        // 向右箭头：箭尾在左，箭头尖在右
        arr << QPoint(leftX, midY - h)
            << QPoint(rightX - h, midY - h)
            << QPoint(rightX - h, midY - h - h)
            << QPoint(rightX, midY)
            << QPoint(rightX - h, midY + h + h)
            << QPoint(rightX - h, midY + h)
            << QPoint(leftX, midY + h);
    }
    else
    {
        // 向左箭头：箭尾在右，箭头尖在左
        arr << QPoint(rightX, midY - h)
            << QPoint(leftX + h, midY - h)
            << QPoint(leftX + h, midY - h - h)
            << QPoint(leftX, midY)
            << QPoint(leftX + h, midY + h + h)
            << QPoint(leftX + h, midY + h)
            << QPoint(rightX, midY + h);
    }

    painter->drawPolygon(arr);

}