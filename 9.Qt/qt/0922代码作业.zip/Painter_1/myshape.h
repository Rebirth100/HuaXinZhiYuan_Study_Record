#ifndef MYSHAPE_H
#define MYSHAPE_H

#include <QPainter>
#include <QPoint>

// 图形抽象基类
class myshape
{
public:
    myshape();
    virtual ~myshape(){}
    virtual void draw(QPainter* painter) = 0;
    QPoint begin;
    QPoint end;
    QColor color;//保存画笔颜色
    int width;
};
// 直线
class MyLine : public myshape
{
public:
    virtual void draw(QPainter* painter) override;
};

// 矩形
class MyRect : public myshape
{
public:
    virtual void draw(QPainter* painter) override;
};

//等腰三角形
class MyTriangle : public myshape
{
public:
    virtual void draw(QPainter* painter) override;
};

//五角星
class MyStar : public myshape
{
public:
    virtual void draw(QPainter* painter) override;
};

//向右箭头
class MyArrow : public myshape
{
public:
    virtual void draw(QPainter* painter) override;
};

#endif // MYSHAPE_H
