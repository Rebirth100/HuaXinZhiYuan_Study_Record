#include "dialog.h"
#include "ui_dialog.h"
#include <QPainter>
#include <QPaintEvent>
#include <QColorDialog>
#include <QInputDialog>
Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);

    m_shape = new MyLine(); // 默认选直线
    is_draw_ = false;

    color_dialog_ = new QColorDialog(this);//color_dialog_：颜色对话框对象，父对象是 this，对话框随窗口自动释放
    connect(color_dialog_,&QColorDialog::colorSelected,//点对话框【确定】按钮后触发选定颜色，才执行 lambda，把选好的颜色存到成员变量`pen_color_`
            [this](const QColor& color)
            {
                m_shape->color = color;
            });

    connect(ui->pushButton_color,&QPushButton::clicked,this,&Dialog::pushButton_color_clicked);
    connect(ui->pushButton_width,&QPushButton::clicked,this,&Dialog::pushButton_width_clicked);
}
Dialog::~Dialog()
{
    delete m_shape;
    delete ui;
}
/*
   Qt 规则：所有绘图代码必须写在paintEvent里面，不能在构造函数直接new QPainter绘图，窗口刷新就会自动调用这个函数。
*/
void Dialog::paintEvent(QPaintEvent* event)//paintEvent 绘图事件
{
    QPainter painter(this);//绘图设备是当前Dialog窗口
    if(is_draw_)
    {
        m_shape->draw(&painter);
    }
    QDialog::paintEvent(event);
}
//鼠标按下
void  Dialog::mousePressEvent(QMouseEvent *event)
{
    m_shape->begin = event->pos();
    is_draw_ = true;
}
//鼠标释放
void  Dialog::mouseReleaseEvent(QMouseEvent *event)
{
    Q_UNUSED(event);
}
//鼠标移动
void  Dialog::mouseMoveEvent(QMouseEvent *event)
{
    m_shape->end = event->pos();//更新鼠标当前位置，作为矩形对角点
    update();//重点：触发重绘，系统自动调用paintEvent()
}

void Dialog::pushButton_color_clicked()//按钮槽函数
{
    color_dialog_->setModal(true);//模态对话框，弹出后父窗口不能点
    color_dialog_->show();//显示对话框
}

void Dialog::pushButton_width_clicked()
{
    //弹出输入整数对话框：标题，提示文字，默认值，最小值，最大值，步长
    bool ok;
    //QInputDialog 静态函数，弹出输入数字的对话框，直接选线条宽度。
    int w = QInputDialog::getInt(this,"选择线条粗细","请输入线条宽度",
                                 m_shape->width ,//默认值
                                 1,//最小像素
                                 30,//最大像素
                                 1,//步长
                                 &ok);
    if(ok)//用户点确定 ok=true；点取消ok=false
    {
        m_shape->width = w;//保存选中的粗细
    }
}


void Dialog::on_comboBox_activated(int index)
{
    // index就是下拉选中第几项，从0开始
    delete m_shape;
    is_draw_ = false;

    switch(index)
    {
    case 0: //直线
        m_shape = new MyLine();
        break;
    case 1: //矩形
        m_shape = new MyRect();
        break;
    case 2: //等腰三角形
        m_shape = new MyTriangle();
        break;
    case 3: //五角星
        m_shape = new MyStar();
        break;
    case 4: //向右箭头
        m_shape = new MyArrow();
        break;
    default:
        m_shape = new MyLine();
        break;
    }

}

