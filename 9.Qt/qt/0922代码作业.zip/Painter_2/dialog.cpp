#include "dialog.h"
#include "ui_dialog.h"
#include <QPainter>
#include <QPaintEvent>
#include <QColorDialog>
#include <QInputDialog>
#include <QMouseEvent>

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);
    setMouseTracking(true);

    color_dialog_ = new QColorDialog(this);
    connect(color_dialog_, &QColorDialog::colorSelected,
            [this](const QColor& color)
            {
                pen_color_ = color;
            });

    connect(ui->pushButton_color, &QPushButton::clicked,
            this, &Dialog::pushButton_color_clicked);
    connect(ui->pushButton_width, &QPushButton::clicked,
            this, &Dialog::pushButton_width_clicked);
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::resetShape()
{
    shape_rect_ = QRect();
    has_shape_ = false;
    grab_point_index_ = PT_NONE;
    is_drawing_new_ = false;
}

// 正式图形的控制点
QRect Dialog::getControlRect(int idx)
{
    return getControlRect(shape_rect_, idx);
}

// 根据传入任意矩形，计算对应索引控制点方块（拖拽预览的时候调用）
QRect Dialog::getControlRect(QRect rect, int idx)
{
    int half = PointSize / 2;
    QPoint center;
    switch(idx)
    {
    case PT_TOPLEFT:
        center = rect.topLeft();
        break;
    case PT_TOPRIGHT:
        center = rect.topRight();
        break;
    case PT_BOTLEFT:
        center = rect.bottomLeft();
        break;
    case PT_BOTRIGHT:
        center = rect.bottomRight();
        break;
    case PT_TOPMID:
        center = QPoint(rect.center().x(), rect.top());
        break;
    case PT_BOTMID:
        center = QPoint(rect.center().x(), rect.bottom());
        break;
    case PT_LEFTMID:
        center = QPoint(rect.left(), rect.center().y());
        break;
    case PT_RIGHTMID:
        center = QPoint(rect.right(), rect.center().y());
        break;
    default:
        return QRect();
    }
    return QRect(center.x()-half, center.y()-half, PointSize, PointSize);
}

void Dialog::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QPainter painter(this);

    // =========拖拽绘制预览阶段：画矩形、椭圆、8个控制点=========
    if (is_drawing_new_)
    {
        QRect tempRect = QRect(drag_draw_begin_, drag_draw_current_).normalized();

        QPen penRect(QColor{53, 235, 255});
        penRect.setWidth(2);
        penRect.setStyle(Qt::DotLine);
        painter.setPen(penRect);
        painter.drawRect(tempRect);

        QPen penEllipse(Qt::black);
        penEllipse.setWidth(2);
        painter.setPen(penEllipse);
        painter.drawEllipse(tempRect);

        // 拖拽过程就绘制8个控制点小方块
        QBrush brush(Qt::white);
        for(int i = 0; i <= PT_RIGHTMID; ++i)
        {
            QRect r = getControlRect(tempRect, i);
            painter.fillRect(r, brush);
            painter.drawRect(r);
        }
    }

    // =========已经画完成的正式图形=========
    if (has_shape_)
    {
        QPen penRect(QColor{53, 235, 255});
        penRect.setWidth(2);
        penRect.setStyle(Qt::DotLine);
        painter.setPen(penRect);
        painter.drawRect(shape_rect_);

        QPen penEllipse(Qt::black);
        penEllipse.setWidth(2);
        painter.setPen(penEllipse);
        painter.drawEllipse(shape_rect_);

        QBrush brush(Qt::white);
        for (int i = 0; i <= PT_RIGHTMID; ++i)
        {
            QRect r = getControlRect(i);
            painter.fillRect(r, brush);
            painter.drawRect(r);
        }
    }
}

void Dialog::mousePressEvent(QMouseEvent *event)
{
    QPoint mp = event->pos();

    if (has_shape_)
    {
        grab_point_index_ = PT_NONE;

        for (int i = 0; i <= PT_RIGHTMID; ++i)
        {
            QRect hot = getControlRect(i).adjusted(-CSize / 2 + PointSize / 2,
                                                   -CSize / 2 + PointSize / 2,
                                                   CSize / 2 - PointSize / 2 - 1,
                                                   CSize / 2 - PointSize / 2 - 1);
            if (hot.contains(mp))
            {
                grab_point_index_ = i;
                drag_start_pos_ = mp;
                setCursor(Qt::CrossCursor);
                return;
            }
        }

        if (shape_rect_.contains(mp))
        {
            grab_point_index_ = PT_MOVE;
            drag_start_pos_ = mp;
            setCursor(Qt::CrossCursor);
            return;
        }

        resetShape();
    }

    is_drawing_new_ = true;
    drag_draw_begin_ = mp;
    drag_draw_current_ = mp;
}

void Dialog::mouseReleaseEvent(QMouseEvent *event)
{
    Q_UNUSED(event);

    if (is_drawing_new_)
    {
        is_drawing_new_ = false;
        shape_rect_ = QRect(drag_draw_begin_, drag_draw_current_).normalized();

        if (shape_rect_.width() > 10 && shape_rect_.height() > 10)
        {
            has_shape_ = true;
        }
        else
        {
            shape_rect_ = QRect();
        }
    }

    grab_point_index_ = PT_NONE;
    setCursor(Qt::ArrowCursor);
}

void Dialog::mouseMoveEvent(QMouseEvent *event)
{
    QPoint mp = event->pos();

    if (is_drawing_new_)
    {
        drag_draw_current_ = mp;
        update();
        return;
    }

    if (grab_point_index_ != PT_NONE)
    {
        QPoint delta = mp - drag_start_pos_;

        if (grab_point_index_ == PT_MOVE)
        {
            shape_rect_.translate(delta);
        }
        else
        {
            switch (grab_point_index_)
            {
            case PT_TOPLEFT:
                shape_rect_.setTopLeft(shape_rect_.topLeft() + delta);
                break;
            case PT_TOPRIGHT:
                shape_rect_.setTopRight(shape_rect_.topRight() + delta);
                break;
            case PT_BOTLEFT:
                shape_rect_.setBottomLeft(shape_rect_.bottomLeft() + delta);
                break;
            case PT_BOTRIGHT:
                shape_rect_.setBottomRight(shape_rect_.bottomRight() + delta);
                break;
            case PT_TOPMID:
                shape_rect_.setTop(shape_rect_.top() + delta.y());
                break;
            case PT_BOTMID:
                shape_rect_.setBottom(shape_rect_.bottom() + delta.y());
                break;
            case PT_LEFTMID:
                shape_rect_.setLeft(shape_rect_.left() + delta.x());
                break;
            case PT_RIGHTMID:
                shape_rect_.setRight(shape_rect_.right() + delta.x());
                break;
            }

            shape_rect_ = shape_rect_.normalized();
            if (shape_rect_.width() < 10)
                shape_rect_.setWidth(10);
            if (shape_rect_.height() < 10)
                shape_rect_.setHeight(10);
        }

        drag_start_pos_ = mp;
        update();
        return;
    }

    if (has_shape_)
    {
        bool onControl = false;
        for (int i = 0; i <= PT_RIGHTMID; ++i)
        {
            QRect hot = getControlRect(i).adjusted(-CSize / 2 + PointSize / 2,
                                                   -CSize / 2 + PointSize / 2,
                                                   CSize / 2 - PointSize / 2 - 1,
                                                   CSize / 2 - PointSize / 2 - 1);
            if (hot.contains(mp))
            {
                onControl = true;
                break;
            }
        }
        setCursor(onControl ? Qt::CrossCursor : Qt::ArrowCursor);
    }
    else
    {
        setCursor(Qt::ArrowCursor);
    }
}

void Dialog::pushButton_color_clicked()
{
    color_dialog_->setModal(true);
    color_dialog_->show();
}

void Dialog::pushButton_width_clicked()
{
    bool ok;
    int w = QInputDialog::getInt(this,"选择线条粗细","请输入线条宽度",
                                 pen_width_ ,
                                 1,
                                 30,
                                 1,
                                 &ok);
    if(ok)
    {
        pen_width_ = w;
    }
}
