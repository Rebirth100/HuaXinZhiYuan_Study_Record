#ifndef DIALOG_H
#define DIALOG_H
#include <QDialog>
#include <QColorDialog>
#include <QPoint>
#include <QRect>

QT_BEGIN_NAMESPACE
namespace Ui {
class Dialog;
}
QT_END_NAMESPACE

class Dialog : public QDialog
{
    Q_OBJECT
public:
    explicit Dialog(QWidget *parent = nullptr);
    ~Dialog() override;

protected:
    void paintEvent(QPaintEvent* event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;

private slots:
    void pushButton_color_clicked();
    void pushButton_width_clicked();

private:
    Ui::Dialog *ui;

    QRect shape_rect_;
    QPoint drag_draw_begin_;
    QPoint drag_draw_current_;
    bool has_shape_ = false;
    bool is_drawing_new_ = false;

    QColor pen_color_{0,0,0};
    QColorDialog* color_dialog_ = nullptr;
    int pen_width_ = 3;

    const int CSize = 16;
    const int PointSize =4;

    enum PointIndex
    {
        PT_NONE = -1,
        PT_TOPLEFT,     //0
        PT_TOPRIGHT,    //1
        PT_BOTLEFT,     //2
        PT_BOTRIGHT,    //3
        PT_TOPMID,      //4
        PT_BOTMID,      //5
        PT_LEFTMID,     //6
        PT_RIGHTMID,    //7
        PT_MOVE         //8
    };

    int grab_point_index_ = PT_NONE;
    QPoint drag_start_pos_;

    QRect getControlRect(int idx);
    QRect getControlRect(QRect rect, int idx);
    void resetShape();
};

#endif // DIALOG_H
